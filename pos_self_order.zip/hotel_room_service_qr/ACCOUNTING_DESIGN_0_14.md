# Room Service 0.14 Bill-to-Room accounting

## Accounting ownership

For a POS-linked Bill-to-Room order, POS is the only source of revenue and VAT.
The guest folio carries the gross receivable through clearing accounts and must
not post the sale or VAT again.

| Event | Debit | Credit |
| --- | --- | --- |
| POS session close | 10530 POS Room Charge Receivable (gross) | Product revenue (net) and VAT Output |
| Room charge transfer | 10539 Unbilled Guest Folio Charges Clearing (gross) | 10530 POS Room Charge Receivable (gross) |
| Guest folio invoice | Guest Accounts Receivable (gross) | 10539 Unbilled Guest Folio Charges Clearing (gross) |

The expected final result is one revenue posting, one VAT posting, zero balance
in 10530, zero balance in 10539, and the gross amount in Guest Receivable.

## Scope rules

- POS-linked Bill-to-Room: uses the accounting bridge above.
- Direct Room Service without a linked POS order: keeps the existing product
  lines on the folio because the folio invoice is the only revenue source.
- Pay at POS: remains POS-only and does not create a folio transfer.
- Restaurant and Room Service revenue separation uses each sold Product's
  standard Odoo Revenue Account.

## Controls

- One posted bridge journal entry per POS order (database unique constraint).
- One folio transfer line per POS order (database unique constraint).
- Retries validate and reuse both records instead of creating duplicates.
- A transfer stops before posting if the payment method, accounts, journal,
  product, tax treatment, company, folio, or amount is inconsistent.
- Business records are created through Odoo ORM. SQL is used only to lock the
  source POS order during the idempotent posting transaction.

## Deployment gate

The module upgrade provisions accounts 10530/10539, journal RCT, and the
tax-free transfer product, but deliberately does not modify POS payment methods.
All Restaurant and Room Service POS sessions must first be closed and validated.
An authorized manager must then use **Configure Bill-to-Room Accounting** on a
Room Service Outlet. Odoo will refuse the action while an affected session is
open.
