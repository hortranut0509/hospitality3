# -*- coding: utf-8 -*-
from odoo import models, fields, api, _
from odoo.exceptions import UserError
from odoo.tools import float_is_zero

class RestaurantTable(models.Model):
    _inherit = 'restaurant.table'

    room_id = fields.Many2one('hotel.room', string="Room", ondelete="cascade")

    @api.depends('room_id', 'room_id.name', 'table_number', 'floor_id')
    def _compute_display_name(self):
        for table in self:
            if table.room_id:
                table.display_name = _("Room %s") % table.room_id.name
            else:
                table.display_name = f"{table.floor_id.name}, {table.table_number}"


class PosConfig(models.Model):
    _inherit = "pos.config"

    hide_in_pos = fields.Boolean(string="Hide in POS Dashboard", default=False)

    @api.model
    def _search(self, domain, offset=0, limit=None, order=None, *, active_test=True, bypass_access=False):
        if self.env.context.get('from_room_service'):
            outlets = self.env['hotel.room.service.outlet'].sudo().search([('active', '=', True)])
            pos_config_ids = outlets.mapped('pos_config_id').ids
            # Safely build domain: convert to list first to avoid double-wrapping a Domain object
            base_domain = fields.Domain(list(domain) if domain else [])
            domain = base_domain & fields.Domain([('id', 'in', pos_config_ids)])
        return super()._search(domain, offset=offset, limit=limit, order=order, active_test=active_test, bypass_access=bypass_access)

    def notify_synchronisation(self, session_id, device_identifier, records={}):
        if self.env.context.get('skip_pos_notification'):
            return False
        return super().notify_synchronisation(session_id, device_identifier, records)

    def read_config_open_orders(self, domain, record_ids=[]):
        # Make a mutable copy to avoid modifying the caller's dict
        domain = dict(domain or {})
        if domain and "pos.order" in domain:
            domain["pos.order"] = fields.Domain(list(domain["pos.order"]) if domain["pos.order"] else []) & fields.Domain([("is_room_service_pending", "=", False)])
        return super().read_config_open_orders(domain, record_ids)

    @api.model
    def _load_pos_data_domain(self, data, config):
        return super()._load_pos_data_domain(data, config)

    @api.model
    def read_pos_orders(self, domain=False):
        return super().read_pos_orders(domain)



class PosOrder(models.Model):
    _inherit = 'pos.order'

    is_room_service_pending = fields.Boolean(string="Room Service Pending", default=False)
    is_posted_to_room = fields.Boolean(compute="_compute_is_posted_to_room", string="Is Posted to Room")
    is_room_service = fields.Boolean(compute="_compute_is_room_service", store=True, string="Is Room Service")

    @api.depends('floating_order_name', 'pos_reference', 'name')
    def _compute_is_room_service(self):
        for order in self:
            name = (order.floating_order_name or order.pos_reference or order.name or "").upper()
            rs_order = self.env['hotel.room.service.order'].sudo().search([('pos_order_id', '=', order.id)], limit=1)
            order.is_room_service = bool(rs_order or name.startswith('RSO/') or 'ROOM SERVICE' in name)

    def _eh_kds_ref(self):
        self.ensure_one()
        rs_order = self.env['hotel.room.service.order'].sudo().search([('pos_order_id', '=', self.id)], limit=1)
        if rs_order:
            return rs_order._eh_kds_ticket_ref()
        if self.table_id and hasattr(self.table_id, 'room_id') and self.table_id.room_id:
            room_name = self.table_id.room_id.name
            digits = "".join(char for char in (self.name or "") if char.isdigit())
            num = str(int(digits[-4:] or "0")) if digits else (self.tracking_number or str(self.id))
            return f"S{num}-{room_name}"
        if hasattr(super(), '_eh_kds_ref'):
            return super()._eh_kds_ref()
        return self.tracking_number or self.pos_reference or self.name or str(self.id)

    def _compute_is_posted_to_room(self):
        for order in self:
            if order.room_charge_folio_line_id:
                order.is_posted_to_room = True
                continue
            # Check if there is a room service order linked to this POS order
            rs_order = self.env['hotel.room.service.order'].sudo().search([('pos_order_id', '=', order.id)], limit=1)
            if rs_order and rs_order._is_posted_to_room():
                order.is_posted_to_room = True
                continue
            # Also check if it's already posted directly on the reservation folio
            if order.hotel_reservation_id and order.hotel_reservation_id.sale_order_id:
                ref = order.pos_reference or order.name
                duplicate_line = self.env['sale.order.line'].sudo().search_count([
                    ('order_id', '=', order.hotel_reservation_id.sale_order_id.id),
                    ('hotel_reservation_id', '=', order.hotel_reservation_id.id),
                    ('name', 'in', [f"Restaurant Bill: {ref}", f"Room Service: {ref}"]),
                ])
                if duplicate_line > 0:
                    order.is_posted_to_room = True
                    continue
            order.is_posted_to_room = False

    @api.model
    def _load_pos_data_fields(self, config_id):
        params = super()._load_pos_data_fields(config_id) if hasattr(super(), '_load_pos_data_fields') else []
        required_fields = [
            'id', 'uuid', 'name', 'display_name', 'access_token',
            'last_order_preparation_change', 'date_order', 'amount_total',
            'amount_paid', 'amount_return', 'user_id', 'amount_tax', 'lines',
            'pricelist_id', 'company_id', 'country_code', 'sequence_number',
            'session_id', 'config_id', 'currency_id', 'currency_rate',
            'is_refund', 'has_refundable_lines', 'state', 'account_move',
            'preset_id', 'floating_order_name', 'general_customer_note',
            'internal_note', 'nb_print', 'pos_reference', 'fiscal_position_id',
            'payment_ids', 'to_invoice', 'shipping_date', 'preset_time',
            'is_invoiced', 'is_tipped', 'tip_amount', 'ticket_code',
            'tracking_number', 'email', 'mobile', 'table_id', 'course_ids',
            'table_stand_number', 'self_ordering_table_id', 'create_date',
            'write_date', 'source', 'partner_id', 'customer_count',
            'is_posted_to_room', 'is_room_service', 'is_room_service_pending',
        ]
        for field_name in required_fields:
            if field_name not in params:
                params.append(field_name)
        return [field_name for field_name in dict.fromkeys(params) if field_name in self._fields]

    @api.model
    def _load_pos_data_read(self, records, config):
        return super()._load_pos_data_read(records, config)

    @api.model
    def get_details(self, shop_id, *args, **kwargs):
        """Compatibility hook for the legacy kitchen screen, if installed."""
        room_orders = self.env['hotel.room.service.order'].sudo().search([
            ('pos_order_id.config_id', '=', shop_id),
            ('state', 'in', [
                'confirmed', 'sent_pos', 'kitchen_preparing', 'kitchen_ready',
                'delivered', 'guest_confirmed', 'folio_posted', 'paid_pos', 'closed',
            ]),
        ])
        room_orders._reconcile_pos_kitchen_status()
        get_details = getattr(super(), 'get_details', None)
        if get_details:
            return get_details(shop_id, *args, **kwargs)
        return {"orders": [], "order_lines": []}

    @api.model
    def sync_from_ui(self, orders):
        is_room_service = False
        for order in orders:
            table_id = order.get('table_id') or order.get('self_ordering_table_id')
            if table_id:
                table = self.env['restaurant.table'].sudo().browse(table_id)
                if table.exists() and table.room_id:
                    is_room_service = True
                    break
        if is_room_service:
            self = self.with_context(skip_pos_notification=True)
        return super().sync_from_ui(orders)

    def _send_notification(self, order_ids):
        visible_orders = order_ids.filtered(lambda order: not order.is_room_service_pending)
        if visible_orders:
            return super()._send_notification(visible_orders)
        return None

    @api.model
    def _process_order(self, order, existing_order):
        self = self.with_context(room_service_current_order_uuid=order.get('uuid'))
        pos_order_id = super()._process_order(order, existing_order)
        pos_order = self.browse(pos_order_id)

        # Check if the order is from self-ordering and linked to a room table
        if pos_order.source in ['mobile', 'kiosk'] and pos_order.self_ordering_table_id:
            table = pos_order.self_ordering_table_id
            if table.room_id:
                # Find the token record for this room
                token_rec = self.env['hotel.room.service.room.token'].sudo().search([
                    ('room_id', '=', table.room_id.id)
                ], limit=1)
                if token_rec:
                    reservation = token_rec._get_active_reservation()
                    if reservation:
                        # Find the corresponding Room Service Outlet
                        outlet = self.env['hotel.room.service.outlet'].sudo().search([
                            ('pos_config_id', '=', pos_order.config_id.id),
                            ('active', '=', True)
                        ], limit=1)
                        if not outlet:
                            outlet = self.env['hotel.room.service.outlet'].sudo().search([('active', '=', True)], limit=1)

                        is_paid = pos_order.amount_paid >= pos_order.amount_total if pos_order.amount_total > 0 else False
                        has_room_charge = any(p.payment_method_id.is_room_charge for p in pos_order.payment_ids)
                        pay_method = 'bill_to_room'
                        if (is_paid and not has_room_charge) or (pos_order.payment_ids and not has_room_charge):
                            pay_method = 'pay_at_pos'

                        auto_send_to_kitchen = bool(is_paid)

                        # The Room Service order is the business record. Keep the
                        # linked POS self-order technical/hidden so it never
                        # becomes a duplicate visible cashier order.
                        rs_order = self.env['hotel.room.service.order'].sudo().create({
                            'token_id': token_rec.id,
                            'reservation_id': reservation.id,
                            'outlet_id': outlet.id if outlet else False,
                            'pos_order_id': pos_order.id,
                            'state': 'sent_pos' if auto_send_to_kitchen else 'draft',
                            'payment_method': pay_method,
                            'guest_submitted': True,
                            'guest_submitted_at': fields.Datetime.now(),
                            'line_ids': [
                                (0, 0, {
                                    'product_id': line.product_id.id,
                                    'name': line.product_id.display_name,
                                    'quantity': line.qty,
                                    'price_unit': line.price_unit,
                                    'note': line.customer_note,
                                }) for line in pos_order.lines
                            ]
                        })

                        # Sync RSO name to POS floating_order_name and RS reference immediately on creation
                        tracking_name = f"{rs_order.name} / Room {table.room_id.name}"
                        pos_order.write({
                            'is_room_service_pending': True,
                            'hotel_reservation_id': reservation.id,
                            'floating_order_name': tracking_name
                        })
                        if auto_send_to_kitchen:
                            rs_order._sync_pos_kitchen_status_from_room_service()
                            try:
                                pos_order.config_id.sudo().notify_synchronisation(
                                    pos_order.session_id.id,
                                    self.env.context.get('device_identifier', 0),
                                    {'pos.order': [pos_order.id]}
                                )
                            except Exception:
                                pass
                        rs_order.write({
                            'pos_reference': tracking_name
                        })

                        # Log integration success
                        log_message = (
                            _("Paid room service order created from POS self-order and sent to Kitchen.")
                            if auto_send_to_kitchen else
                            _("Pending room service order created from POS self-order with tracking name.")
                        )
                        rs_order._log_adapter("system", "success", log_message)
        return pos_order_id

    def _create_hotel_charge(self, reservation, amount, ref):
        pos_order = self[:1] if len(self) == 1 else self.env['pos.order']
        current_uuid = self.env.context.get('room_service_current_order_uuid')
        if current_uuid:
            pos_order = self.env['pos.order'].sudo().search([('uuid', '=', current_uuid)], limit=1)
        if not pos_order:
            candidates = self.env['pos.order'].sudo().search([
                ('hotel_reservation_id', '=', reservation.id),
                '|',
                ('pos_reference', '=', ref),
                ('name', '=', ref),
            ])
            if len(candidates) == 1:
                pos_order = candidates
            elif len(candidates) > 1:
                raise UserError(_("More than one POS order matches this Bill-to-Room reference."))

        if not pos_order:
            raise UserError(_("Unable to identify the source POS order for this Bill-to-Room charge."))

        rs_order = self.env['hotel.room.service.order'].sudo()
        if pos_order:
            rs_order = rs_order.search([('pos_order_id', '=', pos_order.id)], limit=1)

        already_posted = False
        if rs_order and rs_order._is_posted_to_room():
            already_posted = True

        if not already_posted and reservation.sale_order_id:
            duplicate_line = self.env['sale.order.line'].sudo().search([
                ('order_id', '=', reservation.sale_order_id.id),
                ('hotel_reservation_id', '=', reservation.id),
                ('name', 'in', [f"Restaurant Bill: {ref}", f"Room Service: {ref}"]),
            ], limit=1)
            if duplicate_line:
                already_posted = True

        if already_posted:
            if rs_order:
                vals = {
                    'pms_sync_state': 'posted',
                    'pms_folio_id': reservation.sale_order_id.id if reservation.sale_order_id else False,
                    'folio_posted_at': fields.Datetime.now() if not rs_order.folio_posted_at else rs_order.folio_posted_at,
                    'last_error': False,
                }
                if rs_order.state in ['delivered', 'guest_confirmed', 'paid_pos', 'closed']:
                    vals.update({
                        'state': 'folio_posted',
                        'closed_at': fields.Datetime.now() if not rs_order.closed_at else rs_order.closed_at,
                    })
                rs_order.write(vals)
                folio_name = reservation.sale_order_id.name or str(reservation.sale_order_id.id)
                rs_order.message_post(body=_("Room Service Order marked as posted (already posted on folio %s).") % folio_name)
            # Skip posting again, return False (prevent double charge)
            return False

        result = pos_order._post_room_charge_to_folio_accounting_bridge(
            reservation,
            amount,
            ref,
            room_service_order=rs_order,
        )

        if rs_order:
            rs_order._mark_pms_folio_posted(reservation.sale_order_id)
            rs_order._log_adapter("pos", "success", _("POS revenue and VAT were posted once; the gross room charge was transferred to the guest folio through clearing accounts."))
            folio_name = reservation.sale_order_id.name or str(reservation.sale_order_id.id)
            rs_order.message_post(body=_("POS validated the Room Service charge and transferred it to Room Folio %s without posting revenue or VAT twice.") % folio_name)
        return result

    def write(self, vals):
        res = super(PosOrder, self).write(vals)
        if not self.env.context.get('room_service_skip_rs_sync') and ('order_status' in vals or 'state' in vals):
            for order in self:
                rs_order = self.env['hotel.room.service.order'].sudo().search([('pos_order_id', '=', order.id)], limit=1)
                if rs_order and rs_order.state not in ['closed', 'cancelled']:
                    if 'order_status' in vals:
                        new_status = vals['order_status']
                        if new_status == 'draft':
                            if rs_order.state in ['confirmed', 'sent_pos', 'pos_failed']:
                                rs_order.with_context(room_service_skip_pos_kitchen_sync=True).write({
                                    'state': 'kitchen_preparing',
                                    'kitchen_started_at': rs_order.kitchen_started_at or fields.Datetime.now(),
                                })
                        elif new_status in ['waiting', 'ready']:
                            if rs_order.state not in ['delivered', 'folio_posted', 'paid_pos', 'closed']:
                                rs_order.with_context(room_service_skip_pos_kitchen_sync=True).write({
                                    'state': 'kitchen_ready',
                                    'kitchen_ready_at': rs_order.kitchen_ready_at or fields.Datetime.now(),
                                })
                        elif new_status == 'cancel':
                            rs_order.with_context(room_service_skip_pos_kitchen_sync=True).write({'state': 'cancelled', 'closed_at': fields.Datetime.now()})
                    if vals.get('state') == 'cancel':
                        rs_order.with_context(room_service_skip_pos_kitchen_sync=True).write({'state': 'cancelled', 'closed_at': fields.Datetime.now()})
                    elif vals.get('state') in ['paid', 'done'] and rs_order.state in ['delivered', 'guest_confirmed']:
                        if rs_order.payment_method == 'pay_at_pos':
                            rs_order.with_context(room_service_skip_pos_kitchen_sync=True).write({'state': 'paid_pos', 'closed_at': fields.Datetime.now()})
                        elif rs_order.payment_method == 'bill_to_room':
                            has_room_charge = any(p.payment_method_id.is_room_charge for p in order.payment_ids)
                            if not has_room_charge:
                                rs_order.with_context(room_service_skip_pos_kitchen_sync=True).write({'state': 'paid_pos', 'closed_at': fields.Datetime.now(), 'pms_sync_state': 'not_required'})
        return res


class HotelRoomServiceOrder(models.Model):
    _inherit = 'hotel.room.service.order'

    log_ids = fields.One2many(
        "hotel.room.service.integration.log",
        "order_id",
        string="Integration Logs",
        readonly=True,
    )

    def write(self, vals):
        res = super().write(vals)
        if 'state' in vals and not self.env.context.get('room_service_skip_pos_kitchen_sync'):
            self._sync_pos_kitchen_status_from_room_service()
        return res

    def action_send_to_pos(self):
        res = super().action_send_to_pos()
        self._reconcile_pos_kitchen_status()
        return res

    def _get_pos_kitchen_status_from_room_service_state(self):
        self.ensure_one()
        if self.state in ['sent_pos', 'pos_failed']:
            return 'draft'
        if self.state == 'kitchen_preparing':
            return 'draft'
        if self.state == 'kitchen_ready':
            return 'waiting'
        if self.state in ['delivered', 'guest_confirmed', 'folio_posted', 'paid_pos', 'closed']:
            if (
                self.state in ['folio_posted', 'paid_pos', 'closed']
                and self.pos_order_id
                and 'kitchen.screen' in self.env.registry.models
                and 'order_status' in self.pos_order_id.lines._fields
            ):
                kitchen = self.env['kitchen.screen'].sudo().search([
                    ('pos_config_id', '=', self.pos_order_id.config_id.id)
                ], limit=1)
                kitchen_lines = self.pos_order_id.lines
                if kitchen and kitchen.pos_categ_ids:
                    kitchen_lines = kitchen_lines.filtered(
                        lambda line: line.product_id.pos_categ_ids and any(
                            category.id in kitchen.pos_categ_ids.ids
                            for category in line.product_id.pos_categ_ids
                        )
                    )
                elif kitchen:
                    # A kitchen without category restrictions handles all lines.
                    kitchen_lines = self.pos_order_id.lines
                if kitchen_lines:
                    statuses = set(kitchen_lines.mapped('order_status'))
                    if statuses and statuses != {'ready'}:
                        if 'waiting' in statuses or 'ready' in statuses:
                            return 'waiting'
                        return 'draft'
            return 'ready'
        if self.state == 'cancelled':
            return 'cancel'
        return False

    def _sync_pos_kitchen_status_from_room_service(self):
        for order in self:
            pos_order = order.pos_order_id.sudo()
            if not pos_order or 'order_status' not in pos_order._fields:
                order._sync_eh_kds_status_from_room_service()
                continue
            else:
                kitchen_status = order._get_pos_kitchen_status_from_room_service_state()
                if not kitchen_status:
                    order._sync_eh_kds_status_from_room_service()
                    continue
                vals = {'order_status': kitchen_status}
                if 'is_cooking' in pos_order._fields:
                    vals['is_cooking'] = kitchen_status != 'cancel'
                kitchen = self.env['kitchen.screen'].sudo().search([
                    ('pos_config_id', '=', pos_order.config_id.id)
                ], limit=1) if 'kitchen.screen' in self.env.registry.models else False
                kitchen_lines = pos_order.lines
                if kitchen:
                    if kitchen.pos_categ_ids:
                        kitchen_lines = kitchen_lines.filtered(
                            lambda line: line.product_id.pos_categ_ids and any(
                                category.id in kitchen.pos_categ_ids.ids
                                for category in line.product_id.pos_categ_ids
                            )
                        )
                    else:
                        # A kitchen without category restrictions handles all lines.
                        kitchen_lines = pos_order.lines
                    if kitchen_status not in ['cancel', 'ready'] and not kitchen_lines:
                        order._sync_eh_kds_status_from_room_service()
                        continue
                order_vals = {
                    field_name: value
                    for field_name, value in vals.items()
                    if pos_order[field_name] != value
                }
                if order_vals:
                    pos_order.with_context(room_service_skip_rs_sync=True).write(order_vals)
                line_vals = {'order_status': kitchen_status}
                if 'is_cooking' in pos_order.lines._fields:
                    line_vals['is_cooking'] = kitchen_status != 'cancel'
                line_changed = False
                if kitchen_lines:
                    for line in kitchen_lines:
                        changed_line_vals = {
                            field_name: value
                            for field_name, value in line_vals.items()
                            if line[field_name] != value
                        }
                        if changed_line_vals:
                            line.with_context(room_service_skip_rs_sync=True).write(changed_line_vals)
                            line_changed = True
                if line_changed and not order_vals:
                    self.env['bus.bus']._sendone(
                        f'pos_order_created_{pos_order.config_id.id}',
                        'notification',
                        {
                            'res_model': 'pos.order',
                            'message': 'pos_order_updated',
                            'order_id': pos_order.id,
                            'config_id': pos_order.config_id.id,
                        },
                    )
            order._sync_eh_kds_status_from_room_service()

    def _eh_kds_models_available(self):
        return all(model in self.env.registry.models for model in (
            'eh.kds.board',
            'eh.kds.ticket',
            'eh.kds.ticket.item',
            'eh.kds.card',
        ))

    def _eh_kds_visible_states(self):
        return [
            'sent_pos', 'pos_failed', 'kitchen_preparing',
            'kitchen_ready', 'delivered', 'guest_confirmed', 'folio_posted',
            'paid_pos', 'closed',
        ]

    def _eh_kds_ticket_key(self):
        self.ensure_one()
        return 'room_service:%s' % self.id

    def _eh_kds_ticket_ref(self):
        self.ensure_one()
        if self.display_order_number:
            return self.display_order_number
        room = self.room_number or (self.room_id.name if self.room_id else "")
        digits = "".join(char for char in (self.name or "") if char.isdigit())
        num = str(int(digits[-4:] or "0")) if digits else str(self.id or "")
        if room:
            return f"S{num}-{room}"
        return self.pos_reference or self.name or str(self.id)

    def _find_eh_kds_ticket(self):
        self.ensure_one()
        if not self._eh_kds_models_available():
            return self.env['eh.kds.ticket'].sudo()
        Ticket = self.env['eh.kds.ticket'].sudo()
        if self.pos_order_id:
            ticket = Ticket.search([('pos_order_id', '=', self.pos_order_id.id)], limit=1)
            if ticket:
                return ticket
        return Ticket.search([('internal_note', '=', self._eh_kds_ticket_key())], limit=1)

    def _ensure_eh_kds_ticket(self):
        self.ensure_one()
        if not self._eh_kds_models_available():
            return self.env['hotel.room.service.order']
        if self.state not in self._eh_kds_visible_states():
            return self.env['eh.kds.ticket'].sudo()

        Ticket = self.env['eh.kds.ticket'].sudo()
        Item = self.env['eh.kds.ticket.item'].sudo()
        Card = self.env['eh.kds.card'].sudo()
        Board = self.env['eh.kds.board'].sudo()

        if self.pos_order_id:
            self.pos_order_id.sudo()._eh_kds_intake()
            ticket = Ticket.search([('pos_order_id', '=', self.pos_order_id.id)], limit=1)
            if ticket and ticket.ticket_ref != self._eh_kds_ticket_ref():
                ticket.ticket_ref = self._eh_kds_ticket_ref()
            return ticket

        if not Board.search_count([('active', '=', True)]):
            return Ticket

        ticket = Ticket.search([('internal_note', '=', self._eh_kds_ticket_key())], limit=1)
        if not ticket:
            ticket = Ticket.create({
                'ticket_ref': self._eh_kds_ticket_ref(),
                'customer_note': self.guest_note or False,
                'internal_note': self._eh_kds_ticket_key(),
            })
        elif ticket.ticket_ref != self._eh_kds_ticket_ref():
            ticket.write({'ticket_ref': self._eh_kds_ticket_ref()})
        touched = Board.browse()
        config = self.outlet_id.pos_config_id
        for line in self.line_ids:
            line_key = '%s:%s' % (self._eh_kds_ticket_key(), line.id)
            item = ticket.item_ids.filtered(lambda candidate, key=line_key: candidate.pos_order_line_uuid == key)[:1]
            known = (item.quantity - item.cancelled) if item else 0.0
            delta = line.quantity - known
            if delta > 0:
                if not item:
                    note_str = line.note or ''
                    if hasattr(line, 'allergen_flags') and line.allergen_flags:
                        note_str = f"⚠️ ALLERGENS: {line.allergen_flags}" + (f" | {line.note}" if line.note else "")
                    item_vals = {
                        'ticket_id': ticket.id,
                        'product_id': line.product_id.id,
                        'quantity': line.quantity,
                        'pos_order_line_uuid': line_key,
                        'customer_note': note_str or False,
                    }
                    if hasattr(line, 'allergen_flags') and line.allergen_flags and 'allergen_flag' in Item._fields:
                        item_vals['allergen_flag'] = True
                    item = Item.create(item_vals)
                    attr_value_ids = line.product_id.product_template_attribute_value_ids.ids
                    for board, lane in Board._route_item(config, line.product_id, attr_value_ids):
                        card = Card.create({'item_id': item.id, 'lane_id': lane.id})
                        card._log('placed', to_lane=lane, push=False)
                        touched |= board
                else:
                    item.quantity = line.quantity
            elif delta < 0 and item:
                item.cancelled = min(item.quantity, item.cancelled - delta)
                for card in item.card_ids.filtered(lambda candidate: candidate.status != 'voided'):
                    card._log('voided', push=False)
                    touched |= card.board_id
        for board in touched:
            board._kds_push(
                board.access_token,
                'kds.ticket',
                {'ticket_id': ticket.id, 'ticket_ref': ticket.ticket_ref, 'event': 'room_service_intake'},
            )
            board._kds_push(board.access_token, 'kds.status', {'ticket_ref': ticket.ticket_ref})
        return ticket

    def _eh_kds_target_index(self, board):
        self.ensure_one()
        lanes = list(board.lane_ids)
        if not lanes:
            return False
        last = len(lanes) - 1
        if self.state in ['sent_pos', 'pos_failed']:
            return 0
        if self.state == 'kitchen_preparing':
            return min(1, last)
        if self.state == 'kitchen_ready':
            return max(last - 1, 0)
        if self.state in ['delivered', 'guest_confirmed', 'folio_posted', 'paid_pos', 'closed']:
            return last
        return False

    def _sync_eh_kds_status_from_room_service(self):
        if self.env.context.get('room_service_skip_eh_kds_sync'):
            return True
        for order in self:
            if not order._eh_kds_models_available():
                continue
            ticket = order._find_eh_kds_ticket() if order.state == 'cancelled' else order._ensure_eh_kds_ticket()
            if not ticket:
                continue
            cards = ticket.item_ids.card_ids.filtered(lambda card: card.status != 'voided')
            if order.state == 'cancelled':
                cards.with_context(room_service_skip_kds_to_rs_sync=True).void(reason='Room Service cancelled')
                continue
            for board in cards.board_id:
                target = order._eh_kds_target_index(board)
                if target is False:
                    continue
                board_cards = cards.filtered(lambda card, current_board=board: card.board_id == current_board)
                board_cards.with_context(room_service_skip_kds_to_rs_sync=True).move_to(target)
        return True

    def _reconcile_pos_kitchen_status(self):
        """Repair drift and align Room Service stages with Kitchen Display stages."""
        for order in self:
            order._sync_pos_kitchen_status_from_room_service()
            pos_order = order.pos_order_id.sudo()
        return True

    def _get_room_charge_payment_method_for_pos(self, pos_order):
        PaymentMethod = self.env['pos.payment.method'].sudo()
        methods = pos_order.config_id.payment_method_ids
        room_charge = methods.filtered(lambda method: method.is_room_charge)[:1]
        if room_charge:
            return room_charge
        return PaymentMethod.search([
            ('is_room_charge', '=', True),
            ('id', 'in', methods.ids),
        ], limit=1)

    def _sync_pos_status_after_room_bill_posted(self):
        """Mark the linked POS ticket paid with the configured Room Charge method."""
        Payment = self.env['pos.payment'].sudo()
        for order in self:
            pos_order = order.pos_order_id.sudo()
            if (
                not pos_order
                or pos_order.state in ['paid', 'done', 'cancel']
            ):
                continue

            currency = pos_order.currency_id
            amount_due = currency.round(pos_order.amount_total - pos_order.amount_paid)
            if not float_is_zero(amount_due, precision_rounding=currency.rounding):
                payment_method = order._get_room_charge_payment_method_for_pos(pos_order)
                if not payment_method:
                    raise UserError(_("Unable to mark POS order paid: no Room Charge payment method is configured on the POS outlet."))
                company = pos_order.company_id.sudo()
                company._validate_room_charge_accounting_setup()
                if payment_method.receivable_account_id != company.room_charge_pos_receivable_account_id:
                    raise UserError(
                        _("Bill To Room Charge must use the configured POS Room Charge Receivable account before an order can be posted.")
                    )
                Payment.create({
                    'pos_order_id': pos_order.id,
                    'payment_method_id': payment_method.id,
                    'amount': amount_due,
                    'payment_date': fields.Datetime.now(),
                })
                pos_order._compute_prices()

            pos_order.with_context(room_service_skip_rs_sync=True).action_pos_order_paid()
            order._log_adapter("pos", "success", _("Linked POS order marked paid after the room folio charge was posted."))
            try:
                pos_order.config_id.sudo().notify_synchronisation(
                    pos_order.session_id.id,
                    self.env.context.get('device_identifier', 0),
                    {'pos.order': [pos_order.id], 'pos.payment': pos_order.payment_ids.ids}
                )
            except Exception:
                pass
        return True

    def _post_to_pms_folio(self):
        invalid = self.filtered(
            lambda order: order.state not in ['delivered', 'guest_confirmed', 'folio_posted', 'closed']
        )
        if invalid:
            raise UserError(_("Room Service can post to the folio only after staff marks the order delivered."))
        direct_orders = self.filtered(lambda order: not order.pos_order_id)
        res = True
        for direct_order in direct_orders:
            direct_result = super(HotelRoomServiceOrder, direct_order)._post_to_pms_folio()
            if direct_result is not None:
                res = direct_result
        for order in self:
            if not order.pos_order_id:
                if order.pms_sync_state == 'posted':
                    folio_name = order.pms_folio_id.name if order.pms_folio_id else str(order.pms_folio_id.id)
                    order.message_post(body=_("Room Service Order bill posted to Room Folio (Folio: %s) successfully.") % folio_name)
                continue
            if order.payment_method != 'bill_to_room':
                order.write({'pms_sync_state': 'not_required'})
                continue
            order._check_bill_to_room_reservation_is_open()
            if not order.line_ids or not order.total_amount:
                order.write({
                    'pms_sync_state': 'not_required',
                    'state': 'closed',
                    'closed_at': fields.Datetime.now(),
                    'last_error': False,
                })
                continue
            try:
                order._sync_pos_status_after_room_bill_posted()
                ref = order.pos_order_id.pos_reference or order.pos_reference or order.name
                room_charge_amount = sum(order.pos_order_id.payment_ids.filtered(
                    lambda payment: payment.payment_method_id.is_room_charge
                ).mapped('amount'))
                order.pos_order_id._post_room_charge_to_folio_accounting_bridge(
                    order.reservation_id,
                    room_charge_amount,
                    ref,
                    room_service_order=order,
                )
                order._mark_pms_folio_posted(order.reservation_id.sale_order_id)
                folio_name = order.pms_folio_id.name if order.pms_folio_id else str(order.pms_folio_id.id)
                order.message_post(body=_("Room Service Order transferred to Room Folio %s through standard clearing accounting.") % folio_name)
            except Exception as exc:
                order.write({
                    'pms_sync_state': 'failed',
                    'last_error': str(exc),
                    'retry_count': order.retry_count + 1,
                })
                order._log_adapter("pms", "failed", str(exc))
                raise
        return res

    def _is_posted_to_room(self):
        self.ensure_one()
        res = super()._is_posted_to_room()
        if res:
            return True
        if self.reservation_id and self.reservation_id.sale_order_id:
            ref = self.pos_reference or self.name
            duplicate_line = self.env['sale.order.line'].sudo().search_count([
                ('order_id', '=', self.reservation_id.sale_order_id.id),
                ('hotel_reservation_id', '=', self.reservation_id.id),
                ('name', 'in', [
                    f"Restaurant Bill: {ref}",
                    f"Room Service: {ref}",
                    f"Room Service: {self.name}",
                    f"Restaurant Bill: {self.name}"
                ]),
            ])
            if duplicate_line > 0:
                return True
        return False

    def action_confirm_and_send(self):
        for order in self:
            if order._is_posted_to_room():
                raise UserError(_("Already posted to room."))
        return super().action_confirm_and_send()

    def action_sync_to_pms(self):
        posted = self.env['hotel.room.service.order']
        already_posted = self.env['hotel.room.service.order']
        skipped = self.env['hotel.room.service.order']
        failed = self.env['hotel.room.service.order']

        for order in self:
            if order.payment_method != 'bill_to_room':
                order.write({'pms_sync_state': 'not_required'})
                skipped |= order
                continue

            folio = order.pms_folio_id or order.reservation_id.sale_order_id
            if order._is_posted_to_room():
                if folio and order.pms_sync_state != 'posted':
                    order._mark_pms_folio_posted(folio)
                already_posted |= order
                order._log_adapter(
                    "pms",
                    "success",
                    _("Post Bill to Room skipped: this Room Service order is already posted to the room folio."),
                )
                continue

            try:
                order._post_to_pms_folio()
                if order.pms_sync_state == 'posted':
                    posted |= order
                else:
                    skipped |= order
            except Exception:
                failed |= order

        if failed:
            message = _("Some Room Service orders could not be posted. Open the order and check Last Error for the exact reason.")
            notification_type = "danger"
        elif already_posted and not posted:
            message = _("Already posted to room folio. No duplicate charge was created.")
            notification_type = "warning"
        elif posted:
            folios = ", ".join(posted.mapped("pms_folio_id.name")) or _("the guest folio")
            message = _("Room Service charge posted to room folio: %s. POS duplicate payment is blocked.") % folios
            if already_posted:
                message = _("%s Already-posted orders were skipped without duplicate charges.") % message
            notification_type = "success"
        else:
            message = _("No Bill-to-Room charges needed posting.")
            notification_type = "info"

        if failed:
            raise UserError(message)

        return {
            "type": "ir.actions.client",
            "tag": "display_notification",
            "params": {
                "title": _("Post Bill to Room"),
                "message": message,
                "type": notification_type,
                "sticky": False,
                "next": {"type": "ir.actions.client", "tag": "reload"},
            },
        }

    def action_confirm_to_pos(self):
        for order in self:
            if order._is_posted_to_room():
                raise UserError(_("Already posted to room."))
            if not order.guest_submitted:
                raise UserError(_("The guest has not submitted this order yet."))
            if order.state not in ['draft', 'confirmed']:
                raise UserError(_("Only a new staff-review order can be accepted."))
            order.write({
                'staff_confirmed_at': order.staff_confirmed_at or fields.Datetime.now(),
            })
            if order.pos_order_id and order.pos_order_id.is_room_service_pending:
                pos_order = order.pos_order_id
                # Accept the guest self-order into Room Service/KDS while
                # keeping the linked POS draft hidden from normal POS screens.
                order.write({'state': 'confirmed'})
                pos_order.sudo().write({
                    'is_room_service_pending': True,
                    'floating_order_name': f"{order.name} / Room {order.room_id.name}"
                })
                pos_order.config_id.notify_synchronisation(
                    pos_order.session_id.id,
                    self.env.context.get('device_identifier', 0),
                    {'pos.order': [pos_order.id]}
                )
                ref = pos_order.name if pos_order.name != '/' else pos_order.floating_order_name
                order.write({'state': 'sent_pos', 'pos_reference': ref})
                order._log_adapter("system", "success", _("Self-order accepted by staff and sent to Kitchen Display only."))
            else:
                if order.state == 'draft':
                    order.write({'state': 'confirmed'})
                if order.outlet_id.auto_create_pos_order:
                    order.action_send_to_pos()
                else:
                    order.write({'state': 'sent_pos'})
                    order._log_adapter("system", "success", _("Room Service order accepted for the kitchen queue without POS draft order."))
            if order.state in order._eh_kds_visible_states():
                order._ensure_eh_kds_ticket()
                order._sync_eh_kds_status_from_room_service()
        return True

    def write(self, vals):
        res = super().write(vals)
        if not self.env.context.get('room_service_skip_eh_kds_sync'):
            for order in self:
                if order.state in order._eh_kds_visible_states() or order.state == 'cancelled':
                    if order.state != 'cancelled':
                        order._ensure_eh_kds_ticket()
                    order._sync_eh_kds_status_from_room_service()
        return res

    def action_cancel_before_pos(self):
        res = super().action_cancel_before_pos()
        for order in self:
            if order.pos_order_id and order.pos_order_id.state == 'draft':
                order.pos_order_id.sudo().write({'state': 'cancel'})
                if 'order_status' in order.pos_order_id._fields:
                    order.pos_order_id.sudo().write({'order_status': 'cancel'})
        return res


class EhKdsCard(models.Model):
    _inherit = 'eh.kds.card'

    def move_to(self, index, kind=None):
        res = super().move_to(index, kind=kind)
        if not self.env.context.get('room_service_skip_kds_to_rs_sync'):
            self._sync_room_service_from_eh_kds()
        return res

    def void(self, reason=None):
        res = super().void(reason=reason)
        if not self.env.context.get('room_service_skip_kds_to_rs_sync'):
            self._sync_room_service_from_eh_kds(cancelled=True)
        return res

    def _room_service_from_ticket(self, ticket):
        RoomService = self.env['hotel.room.service.order'].sudo()
        if ticket.pos_order_id:
            order = RoomService.search([('pos_order_id', '=', ticket.pos_order_id.id)], limit=1)
            if order:
                return order
        marker = ticket.internal_note or ''
        if marker.startswith('room_service:'):
            try:
                order = RoomService.browse(int(marker.split(':', 1)[1]))
            except (TypeError, ValueError):
                return RoomService
            return order if order.exists() else RoomService
        return RoomService

    def _room_service_state_from_ticket(self, ticket, cancelled=False):
        items = ticket.item_ids.filtered(lambda i: (i.quantity - i.cancelled) > 0)
        if not items:
            if cancelled:
                return 'cancelled'
            return False
        active_items = items.filtered(lambda item: item.card_ids.filtered(lambda card: card.status != 'voided'))
        if cancelled and not active_items:
            return 'cancelled'
        items = active_items or items

        item_ranks = []
        for item in items:
            cards = item.card_ids.filtered(lambda card: card.status != 'voided')
            if not cards:
                item_ranks.append(2)
                continue
            item_rank = 0
            for card in cards:
                lanes = list(card.board_id.lane_ids)
                if not lanes or card.lane_id not in lanes:
                    continue
                idx = lanes.index(card.lane_id)
                last_idx = len(lanes) - 1
                ready_idx = max(last_idx - 1, 0)
                name = (card.lane_id.name or "").lower()
                if "complete" in name or "done" in name or "deliver" in name or idx >= last_idx:
                    item_rank = max(item_rank, 3)
                elif "ready" in name or idx >= ready_idx:
                    item_rank = max(item_rank, 2)
                elif idx >= 1 or "cook" in name or "prep" in name:
                    item_rank = max(item_rank, 1)
            item_ranks.append(item_rank)

        if not item_ranks:
            return False

        if all(r == 3 for r in item_ranks):
            aggregated = 3
        elif all(r >= 2 for r in item_ranks):
            aggregated = 2
        elif any(r >= 1 for r in item_ranks):
            aggregated = 1
        else:
            aggregated = 0

        return {
            0: 'sent_pos',
            1: 'kitchen_preparing',
            2: 'kitchen_ready',
            3: 'kitchen_ready',
        }.get(aggregated)

    def _sync_room_service_from_eh_kds(self, cancelled=False):
        for ticket in self.ticket_id:
            order = self._room_service_from_ticket(ticket)
            if not order or order.state in ['closed', 'folio_posted', 'paid_pos']:
                continue
            new_state = self._room_service_state_from_ticket(ticket, cancelled=cancelled)
            if not new_state or order.state == new_state:
                continue
            old_state = order.state
            vals = {'state': new_state}
            if new_state == 'cancelled':
                vals['closed_at'] = fields.Datetime.now()
            elif new_state == 'kitchen_preparing':
                vals['kitchen_started_at'] = order.kitchen_started_at or fields.Datetime.now()
            elif new_state == 'kitchen_ready':
                vals['kitchen_ready_at'] = order.kitchen_ready_at or fields.Datetime.now()
            order.with_context(
                room_service_skip_pos_kitchen_sync=True,
                room_service_skip_eh_kds_sync=True,
            ).write(vals)
            order._log_adapter(
                "kds",
                "success",
                _("Kitchen Display updated Room Service status from %(old_state)s to %(new_state)s.") % {
                    "old_state": dict(order._fields["state"].selection).get(old_state, old_state),
                    "new_state": dict(order._fields["state"].selection).get(new_state, new_state),
                },
                {
                    "ticket_id": ticket.id,
                    "ticket_ref": ticket.ticket_ref,
                    "card_ids": self.filtered(lambda card, current_ticket=ticket: card.ticket_id == current_ticket).ids,
                    "cancelled": cancelled,
                },
            )
        return True
