# -*- coding: utf-8 -*-
from odoo import Command, _, api, fields, models
from odoo.exceptions import UserError, ValidationError
from odoo.tools import float_compare, float_is_zero


POS_ROOM_RECEIVABLE_CODE = "10530"
FOLIO_CLEARING_CODE = "10539"
TRANSFER_JOURNAL_CODE = "RCT"
TRANSFER_PRODUCT_CODE = "RS-FOLIO-TRANSFER"


class ResCompany(models.Model):
    _inherit = "res.company"

    room_charge_pos_receivable_account_id = fields.Many2one(
        "account.account",
        string="POS Room Charge Receivable",
        copy=False,
        help="Receivable debited by POS for Bill-to-Room payments and cleared by the Room Charge transfer entry.",
    )
    room_charge_folio_clearing_account_id = fields.Many2one(
        "account.account",
        string="Unbilled Guest Folio Clearing",
        copy=False,
        help="Temporary asset used between the POS room-charge transfer and the guest folio invoice.",
    )
    room_charge_transfer_journal_id = fields.Many2one(
        "account.journal",
        string="Room Charge Transfer Journal",
        copy=False,
    )
    room_charge_transfer_product_id = fields.Many2one(
        "product.product",
        string="Room Charge Folio Transfer Product",
        copy=False,
    )

    def _account_company_domain(self):
        self.ensure_one()
        Account = self.env["account.account"]
        if "company_ids" in Account._fields:
            return [("company_ids", "in", [self.id])]
        if "company_id" in Account._fields:
            return [("company_id", "=", self.id)]
        return []

    def _account_company_values(self):
        self.ensure_one()
        Account = self.env["account.account"]
        if "company_ids" in Account._fields:
            return {"company_ids": [Command.set([self.id])]}
        if "company_id" in Account._fields:
            return {"company_id": self.id}
        return {}

    def _get_or_create_room_charge_account(self, code, name, account_type):
        self.ensure_one()
        Account = self.env["account.account"].sudo().with_company(self)
        account = Account.search([("code", "=", code)] + self._account_company_domain(), limit=1)
        if not account:
            values = {
                "name": name,
                "code": code,
                "account_type": account_type,
                "reconcile": True,
            }
            values.update(self._account_company_values())
            account = Account.create(values)
        if account.account_type != account_type or not account.reconcile:
            raise UserError(
                _(
                    "Account %(code)s must use type %(account_type)s and Allow Reconciliation before Bill-to-Room accounting can be enabled.",
                    code=code,
                    account_type=account_type,
                )
            )
        return account

    def _get_or_create_room_charge_transfer_journal(self):
        self.ensure_one()
        Journal = self.env["account.journal"].sudo().with_company(self)
        journal = Journal.search([
            ("code", "=", TRANSFER_JOURNAL_CODE),
            ("company_id", "=", self.id),
        ], limit=1)
        if not journal:
            journal = Journal.create({
                "name": _("Room Charge Transfer"),
                "code": TRANSFER_JOURNAL_CODE,
                "type": "general",
                "company_id": self.id,
            })
        if journal.type != "general":
            raise UserError(_("Journal code %s must be a Miscellaneous journal.") % TRANSFER_JOURNAL_CODE)
        return journal

    def _get_or_create_room_charge_transfer_product(self, clearing_account):
        self.ensure_one()
        ProductTemplate = self.env["product.template"].sudo().with_company(self)
        template = ProductTemplate.search([("default_code", "=", TRANSFER_PRODUCT_CODE)], limit=1)
        if not template:
            values = {
                "name": _("POS Room Charge Folio Transfer"),
                "default_code": TRANSFER_PRODUCT_CODE,
                "type": "service",
                "sale_ok": True,
                "purchase_ok": False,
                "invoice_policy": "order",
                "list_price": 0.0,
                "taxes_id": [Command.clear()],
                "property_account_income_id": clearing_account.id,
            }
            if "company_id" in ProductTemplate._fields:
                values["company_id"] = self.id
            template = ProductTemplate.create(values)
        product = template.product_variant_id
        effective_income = product._get_product_accounts().get("income")
        if template.type != "service" or template.taxes_id or effective_income != clearing_account:
            raise UserError(
                _(
                    "Product %(product)s must be a tax-free service whose Income Account is %(account)s.",
                    product=product.display_name,
                    account=clearing_account.display_name,
                )
            )
        return product

    def _ensure_room_charge_accounting_setup(self):
        """Provision standard accounts and transfer records without touching POS methods."""
        for company in self:
            pos_receivable = company._get_or_create_room_charge_account(
                POS_ROOM_RECEIVABLE_CODE,
                _("POS Room Charge Receivable"),
                "asset_receivable",
            )
            clearing = company._get_or_create_room_charge_account(
                FOLIO_CLEARING_CODE,
                _("Unbilled Guest Folio Charges Clearing"),
                "asset_current",
            )
            journal = company._get_or_create_room_charge_transfer_journal()
            product = company._get_or_create_room_charge_transfer_product(clearing)
            company.sudo().write({
                "room_charge_pos_receivable_account_id": pos_receivable.id,
                "room_charge_folio_clearing_account_id": clearing.id,
                "room_charge_transfer_journal_id": journal.id,
                "room_charge_transfer_product_id": product.id,
            })
        return True

    def _validate_room_charge_accounting_setup(self):
        for company in self:
            pos_receivable = company.room_charge_pos_receivable_account_id
            clearing = company.room_charge_folio_clearing_account_id
            journal = company.room_charge_transfer_journal_id
            product = company.room_charge_transfer_product_id
            missing = []
            if not pos_receivable:
                missing.append(_("POS Room Charge Receivable"))
            if not clearing:
                missing.append(_("Unbilled Guest Folio Clearing"))
            if not journal:
                missing.append(_("Room Charge Transfer Journal"))
            if not product:
                missing.append(_("Room Charge Folio Transfer Product"))
            if missing:
                raise UserError(
                    _("Bill-to-Room accounting is not configured. Missing: %s") % ", ".join(missing)
                )
            if pos_receivable == clearing:
                raise UserError(_("POS receivable and folio clearing must be different accounts."))
            if pos_receivable.account_type != "asset_receivable" or not pos_receivable.reconcile:
                raise UserError(_("POS Room Charge Receivable must be a reconcilable Receivable account."))
            if clearing.account_type != "asset_current" or not clearing.reconcile:
                raise UserError(_("Unbilled Guest Folio Clearing must be a reconcilable Current Assets account."))
            if journal.type != "general":
                raise UserError(_("Room Charge Transfer Journal must be a Miscellaneous journal."))
            if product.taxes_id:
                raise UserError(_("Room Charge Folio Transfer Product must have no customer taxes."))
            effective_income = product._get_product_accounts().get("income")
            if effective_income != clearing:
                raise UserError(_("Room Charge Folio Transfer Product must use the folio clearing account."))
        return True

    def _room_charge_payment_methods(self):
        self.ensure_one()
        methods = self.env["pos.payment.method"].sudo().search([("is_room_charge", "=", True)])
        if "company_id" in methods._fields:
            methods = methods.filtered(lambda method: not method.company_id or method.company_id == self)
        if "config_ids" in methods._fields:
            methods = methods.filtered(
                lambda method: not method.config_ids or self in method.config_ids.mapped("company_id")
            )
        return methods

    def action_configure_room_charge_accounting(self):
        self.ensure_one()
        company = self.sudo()
        company._ensure_room_charge_accounting_setup()
        methods = company._room_charge_payment_methods()
        if not methods:
            raise UserError(_("No Bill To Room Charge POS payment method was found for this company."))
        configs = methods.mapped("config_ids") if "config_ids" in methods._fields else self.env["pos.config"]
        open_sessions = self.env["pos.session"].sudo().search([
            ("config_id", "in", configs.ids),
            ("state", "!=", "closed"),
        ])
        if open_sessions:
            raise UserError(
                _(
                    "Close and validate these POS sessions before configuring Bill-to-Room accounting: %s",
                    ", ".join(open_sessions.mapped("display_name")),
                )
            )
        methods.write({"receivable_account_id": company.room_charge_pos_receivable_account_id.id})
        company._validate_room_charge_accounting_setup()
        return {
            "type": "ir.actions.client",
            "tag": "display_notification",
            "params": {
                "title": _("Bill-to-Room Accounting"),
                "message": _("Standard POS revenue, VAT, clearing, and guest-folio transfer accounts are configured."),
                "type": "success",
                "sticky": False,
                "next": {"type": "ir.actions.client", "tag": "reload"},
            },
        }


class PosOrder(models.Model):
    _inherit = "pos.order"

    room_charge_bridge_move_id = fields.Many2one(
        "account.move",
        string="Room Charge Transfer Entry",
        readonly=True,
        copy=False,
        index=True,
    )
    room_charge_folio_line_id = fields.Many2one(
        "sale.order.line",
        string="Room Charge Folio Line",
        readonly=True,
        copy=False,
        index=True,
    )
    room_charge_folio_id = fields.Many2one(
        "sale.order",
        string="Room Charge Folio",
        readonly=True,
        copy=False,
        index=True,
    )

    def _validate_room_charge_payment_account(self, amount):
        self.ensure_one()
        company = self.company_id.sudo()
        company._validate_room_charge_accounting_setup()
        room_payments = self.payment_ids.filtered(lambda payment: payment.payment_method_id.is_room_charge)
        if not room_payments:
            raise UserError(_("The POS order has no Bill To Room Charge payment."))
        payment_methods = room_payments.mapped("payment_method_id")
        invalid_methods = payment_methods.filtered(
            lambda method: method.receivable_account_id != company.room_charge_pos_receivable_account_id
        )
        if invalid_methods:
            raise UserError(
                _(
                    "Bill-to-Room accounting is not ready. Payment method %(method)s must use %(account)s.",
                    method=", ".join(invalid_methods.mapped("display_name")),
                    account=company.room_charge_pos_receivable_account_id.display_name,
                )
            )
        paid_to_room = sum(room_payments.mapped("amount"))
        rounding = self.currency_id.rounding
        if float_compare(paid_to_room, amount, precision_rounding=rounding) != 0:
            raise UserError(
                _(
                    "Bill-to-Room payment amount (%(paid).2f) does not match the folio transfer amount (%(amount).2f).",
                    paid=paid_to_room,
                    amount=amount,
                )
            )
        return room_payments

    def _validate_existing_room_charge_bridge(self, folio, amount):
        self.ensure_one()
        company = self.company_id
        currency = self.currency_id
        move = self.room_charge_bridge_move_id or self.env["account.move"].sudo().search([
            ("room_charge_pos_order_id", "=", self.id),
        ], limit=1)
        line = self.room_charge_folio_line_id or self.env["sale.order.line"].sudo().search([
            ("room_charge_pos_order_id", "=", self.id),
        ], limit=1)
        if move:
            if move.state != "posted" or move.company_id != company:
                raise UserError(_("The existing Room Charge transfer entry is not a posted entry for the POS company."))
            clearing_balance = sum(move.line_ids.filtered(
                lambda move_line: move_line.account_id == company.room_charge_folio_clearing_account_id
            ).mapped("balance"))
            receivable_balance = sum(move.line_ids.filtered(
                lambda move_line: move_line.account_id == company.room_charge_pos_receivable_account_id
            ).mapped("balance"))
            if (
                float_compare(clearing_balance, amount, precision_rounding=currency.rounding) != 0
                or float_compare(receivable_balance, -amount, precision_rounding=currency.rounding) != 0
            ):
                raise UserError(_("The existing Room Charge transfer entry does not match the requested amount."))
        if line:
            if line.order_id != folio or line.product_id != company.room_charge_transfer_product_id:
                raise UserError(_("The existing Room Charge folio line does not match the configured folio or transfer product."))
            if line.tax_ids or float_compare(line.price_total, amount, precision_rounding=currency.rounding) != 0:
                raise UserError(_("The existing Room Charge folio line has an unexpected tax or amount."))
        if move and line:
            values = {}
            if self.room_charge_bridge_move_id != move:
                values["room_charge_bridge_move_id"] = move.id
            if self.room_charge_folio_line_id != line:
                values["room_charge_folio_line_id"] = line.id
            if self.room_charge_folio_id != folio:
                values["room_charge_folio_id"] = folio.id
            if values:
                self.sudo().write(values)
        return move, line

    def _post_room_charge_to_folio_accounting_bridge(self, reservation, amount, ref, room_service_order=False):
        """Transfer one POS room charge to the folio without a second revenue or VAT posting."""
        self.ensure_one()
        if amount <= 0:
            raise UserError(_("Bill-to-Room transfer amount must be positive."))
        if not reservation or reservation.company_id != self.company_id:
            raise UserError(_("POS order and hotel reservation must belong to the same company."))
        self._validate_room_charge_payment_account(amount)
        reservation = reservation.sudo()
        if not reservation.sale_order_id:
            reservation.action_create_folio()
        folio = reservation.sale_order_id.sudo()
        if not folio or folio.company_id != self.company_id:
            raise UserError(_("Unable to create or find a guest folio in the POS company."))
        if self.currency_id != self.company_id.currency_id or folio.currency_id != self.company_id.currency_id:
            raise UserError(
                _("Bill-to-Room clearing currently requires POS, folio, and company to use the same currency.")
            )
        if folio.state in ("cancel", "done"):
            raise UserError(_("The guest folio is closed and cannot receive a Room Charge transfer."))

        self.env.cr.execute("SELECT id FROM pos_order WHERE id = %s FOR UPDATE", [self.id])
        self.invalidate_recordset([
            "room_charge_bridge_move_id",
            "room_charge_folio_line_id",
            "room_charge_folio_id",
        ])
        bridge_move, folio_line = self._validate_existing_room_charge_bridge(folio, amount)
        company = self.company_id.sudo()
        company._validate_room_charge_accounting_setup()
        partner = folio.partner_invoice_id or folio.partner_id
        transfer_date = fields.Date.context_today(self)
        source_name = ref or self.pos_reference or self.name

        if not bridge_move:
            bridge_move = self.env["account.move"].sudo().with_company(company).create({
                "move_type": "entry",
                "journal_id": company.room_charge_transfer_journal_id.id,
                "date": transfer_date,
                "ref": _("POS Room Charge Transfer: %s") % source_name,
                "room_charge_pos_order_id": self.id,
                "room_service_qr_order_id": room_service_order.id if room_service_order else False,
                "line_ids": [
                    Command.create({
                        "name": _("Transfer POS room charge to guest folio clearing"),
                        "account_id": company.room_charge_folio_clearing_account_id.id,
                        "partner_id": partner.id,
                        "debit": amount,
                        "credit": 0.0,
                    }),
                    Command.create({
                        "name": _("Clear POS room charge receivable"),
                        "account_id": company.room_charge_pos_receivable_account_id.id,
                        "partner_id": partner.id,
                        "date_maturity": transfer_date,
                        "debit": 0.0,
                        "credit": amount,
                    }),
                ],
            })
            bridge_move.action_post()

        if not folio_line:
            line_values = {
                "order_id": folio.id,
                "product_id": company.room_charge_transfer_product_id.id,
                "name": _("POS Room Charge Transfer: %s") % source_name,
                "product_uom_qty": 1.0,
                "price_unit": amount,
                "tax_ids": [Command.clear()],
                "hotel_reservation_id": reservation.id,
                "room_charge_pos_order_id": self.id,
                "room_service_qr_order_id": room_service_order.id if room_service_order else False,
            }
            if "product_uom_id" in self.env["sale.order.line"]._fields:
                line_values["product_uom_id"] = company.room_charge_transfer_product_id.uom_id.id
            if room_service_order and "hotel_business_date" in self.env["sale.order.line"]._fields:
                line_values["hotel_business_date"] = room_service_order.hotel_business_date
            folio_line = self.env["sale.order.line"].sudo().with_company(company).create(line_values)

        self.sudo().write({
            "room_charge_bridge_move_id": bridge_move.id,
            "room_charge_folio_line_id": folio_line.id,
            "room_charge_folio_id": folio.id,
        })
        return folio_line


class AccountMove(models.Model):
    _inherit = "account.move"

    room_charge_pos_order_id = fields.Many2one(
        "pos.order",
        string="Room Charge POS Order",
        readonly=True,
        copy=False,
        index=True,
        ondelete="restrict",
    )
    room_service_qr_order_id = fields.Many2one(
        "hotel.room.service.order",
        string="Room Service Order",
        readonly=True,
        copy=False,
        index=True,
        ondelete="set null",
    )

    _room_charge_bridge_pos_unique = models.Constraint(
        "UNIQUE(room_charge_pos_order_id)",
        "A POS order can have only one Room Charge transfer entry.",
    )


class SaleOrderLine(models.Model):
    _inherit = "sale.order.line"

    room_charge_pos_order_id = fields.Many2one(
        "pos.order",
        string="Room Charge POS Order",
        readonly=True,
        copy=False,
        index=True,
        ondelete="restrict",
    )
    room_service_qr_order_id = fields.Many2one(
        "hotel.room.service.order",
        string="Room Service Order",
        readonly=True,
        copy=False,
        index=True,
        ondelete="set null",
    )

    _room_charge_folio_line_pos_unique = models.Constraint(
        "UNIQUE(room_charge_pos_order_id)",
        "A POS order can have only one Room Charge folio transfer line.",
    )

    @api.constrains("room_charge_pos_order_id", "product_id", "tax_ids", "price_unit", "product_uom_qty")
    def _check_room_charge_transfer_line(self):
        for line in self.filtered("room_charge_pos_order_id"):
            company = line.order_id.company_id
            if line.product_id != company.room_charge_transfer_product_id:
                raise ValidationError(_("A Room Charge transfer line must use the configured transfer product."))
            if line.tax_ids:
                raise ValidationError(_("A Room Charge transfer line cannot carry customer taxes."))
            if line.product_uom_qty != 1.0 or line.price_unit <= 0.0 or float_is_zero(
                line.price_unit, precision_rounding=line.currency_id.rounding
            ):
                raise ValidationError(_("A Room Charge transfer line must contain one positive gross transfer amount."))


class HotelRoomServiceOrder(models.Model):
    _inherit = "hotel.room.service.order"

    room_charge_bridge_move_id = fields.Many2one(
        related="pos_order_id.room_charge_bridge_move_id",
        string="Room Charge Transfer Entry",
        readonly=True,
        store=True,
    )
    room_charge_folio_line_id = fields.Many2one(
        related="pos_order_id.room_charge_folio_line_id",
        string="Room Charge Folio Line",
        readonly=True,
        store=True,
    )


class HotelRoomServiceOutlet(models.Model):
    _inherit = "hotel.room.service.outlet"

    def action_configure_room_charge_accounting(self):
        self.ensure_one()
        return self.env.company.action_configure_room_charge_accounting()
