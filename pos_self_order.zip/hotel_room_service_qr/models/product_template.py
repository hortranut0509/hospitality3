from odoo import api, fields, models
from odoo.exceptions import ValidationError


class ProductTemplate(models.Model):
    _inherit = "product.template"

    available_in_room_service = fields.Boolean(
        string="Available in Room Service",
        default=False,
        help=(
            "Show this product on the guest QR menu and in the Room Service "
            "staff Add/Change Item catalog. The product must also be available "
            "in Point of Sale so it can be sent to the kitchen display."
        ),
    )
    room_service_category_id = fields.Many2one(
        "hotel.room.service.menu.category",
        string="Room Service Category",
        help="Optional guest-menu category. If empty, the first Point of Sale category is used.",
    )
    room_service_description = fields.Text(
        string="Room Service Description",
        help="Optional guest-facing description. If empty, the Sales Description is used.",
    )
    room_service_sequence = fields.Integer(
        string="Room Service Sequence",
        default=10,
        help="Lower values appear first on the guest menu and staff item selector.",
    )

    @api.onchange("available_in_room_service")
    def _onchange_available_in_room_service(self):
        if self.available_in_room_service:
            self.available_in_pos = True

    @api.constrains("available_in_room_service", "available_in_pos")
    def _check_room_service_requires_pos(self):
        invalid_products = self.filtered(
            lambda product: product.available_in_room_service and not product.available_in_pos
        )
        if invalid_products:
            raise ValidationError(
                "A Room Service product must also be available in Point of Sale. "
                "Enable 'Available in POS' before saving."
            )
