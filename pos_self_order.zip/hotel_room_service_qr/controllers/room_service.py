import json
import zipfile
from io import BytesIO

from psycopg2 import IntegrityError

from odoo import _, http, fields
from odoo.exceptions import AccessError
from odoo.http import content_disposition, request


ROOM_SERVICE_STAFF_GROUPS = (
    "hotel_management.group_hotel_front_office",
    "hotel_management.group_hotel_manager",
    "base.group_system",
)


def _require_room_service_staff():
    if not any(request.env.user.has_group(group) for group in ROOM_SERVICE_STAFF_GROUPS):
        raise AccessError(_("You are not allowed to operate the Room Service monitor."))


class HotelRoomServiceKitchenStatusDisplay(http.Controller):
    """Compatibility endpoints backed by the eh_pos_kds Kitchen Display."""

    @http.route("/pos/kitchen/status", type="http", auth="user", website=True)
    def kitchen_status_display(self, pos_config_id=None, **kwargs):
        _require_room_service_staff()
        board = self._get_kds_board(pos_config_id)
        if board:
            return request.redirect("/eh_kds/status/%s" % board.access_token)
        return request.not_found()

    @http.route("/pos/kitchen/status/data", type="http", auth="user")
    def kitchen_status_display_data(self, pos_config_id=None, **kwargs):
        _require_room_service_staff()
        payload = self._get_status_payload(self._safe_int(pos_config_id))
        return request.make_response(
            json.dumps(payload),
            headers=[("Content-Type", "application/json")],
        )

    def _safe_int(self, value):
        try:
            return int(value or 0)
        except (TypeError, ValueError):
            return 0

    def _get_kds_board(self, pos_config_id=None):
        Board = request.env["eh.kds.board"].sudo()
        domain = [("active", "=", True)]
        if pos_config_id:
            board = Board.search(domain + [("pos_config_ids", "in", [pos_config_id])], limit=1)
            if board:
                return board
        return Board.search(domain, order="sequence, id", limit=1)

    def _get_status_payload(self, config_id):
        board = self._get_kds_board(config_id)
        if not board:
            return {
                "kitchen": {},
                "almost_ready": [],
                "ready": [],
                "counts": {"almost_ready": 0, "ready": 0},
                "last_updated": fields.Datetime.now().isoformat(),
            }

        request.env["hotel.room.service.order"].sudo().search([
            ("state", "in", HotelRoomServiceQrController.DISPLAY_STATES),
        ])._reconcile_pos_kitchen_status()
        data = board._kds_status_data()
        almost_ready = [self._serialize_kds_status_item(item, "preparing") for item in data.get("preparing", [])]
        ready = [self._serialize_kds_status_item(item, "ready") for item in data.get("ready", [])]

        return {
            "kitchen": {
                "id": board.id,
                "name": board.name,
                "pos_config_id": config_id or 0,
                "pos_name": board.name,
            },
            "almost_ready": almost_ready[:30],
            "ready": ready[:30],
            "counts": {
                "almost_ready": len(almost_ready),
                "ready": len(ready),
            },
            "last_updated": fields.Datetime.now().isoformat(),
        }

    def _serialize_kds_status_item(self, item, status):
        return {
            "id": item.get("ticket_id"),
            "name": item.get("ref") or str(item.get("ticket_id") or ""),
            "customer": "",
            "table": "",
            "status": status,
            "time": "",
            "eta": "",
            "wait_minutes": 0,
        }


class HotelRoomServiceQrController(http.Controller):
    GUEST_PROGRESS_STEP_BY_STATE = {
        "draft": 0,
        "confirmed": 1,
        "sent_pos": 1,
        "pos_failed": 1,
        "kitchen_preparing": 2,
        "kitchen_ready": 3,
        "delivered": 4,
        "guest_confirmed": 4,
        "folio_posted": 4,
        "paid_pos": 4,
        "closed": 4,
        "cancelled": 0,
    }
    MONITOR_ACTIVE_STATES = [
        "draft",
        "confirmed",
        "sent_pos",
        "pos_failed",
        "kitchen_preparing",
        "kitchen_ready",
        "delivered",
        "guest_confirmed",
    ]
    MONITOR_TERMINAL_STATES = [
        "folio_posted",
        "paid_pos",
        "closed",
    ]
    DISPLAY_STATES = MONITOR_ACTIVE_STATES + MONITOR_TERMINAL_STATES
    ROOM_STATUS_ACTIVE_STATES = [
        "draft",
        "confirmed",
        "sent_pos",
        "pos_failed",
        "kitchen_preparing",
        "kitchen_ready",
        "delivered",
        "guest_confirmed",
    ]
    GUEST_FINAL_STATES = {"folio_posted", "paid_pos", "closed", "cancelled"}

    def _serialize_guest_order(self, order):
        order = order.sudo()
        currency = (
            order.currency_id
            or order.reservation_id.company_id.currency_id
            or request.env.company.sudo().currency_id
        )
        state = order.state

        status_by_state = {
            "draft": (
                self.GUEST_PROGRESS_STEP_BY_STATE["draft"],
                "Awaiting Room Service Review",
                "Room Service is reviewing your order and may call you to confirm changes.",
                "badge-confirmed",
                "bi-clock-fill",
            ),
            "confirmed": (
                self.GUEST_PROGRESS_STEP_BY_STATE["confirmed"],
                "Confirmed by Room Service",
                "Your reviewed order is being sent to the kitchen.",
                "badge-confirmed",
                "bi-check-circle-fill",
            ),
            "sent_pos": (
                self.GUEST_PROGRESS_STEP_BY_STATE["sent_pos"],
                "Sent to Kitchen",
                "The kitchen has received your confirmed order.",
                "badge-confirmed",
                "bi-check-circle-fill",
            ),
            "pos_failed": (
                self.GUEST_PROGRESS_STEP_BY_STATE["pos_failed"],
                "Kitchen Send Delayed",
                "Room Service is correcting a kitchen connection problem.",
                "badge-cancelled",
                "bi-exclamation-circle-fill",
            ),
            "kitchen_preparing": (
                self.GUEST_PROGRESS_STEP_BY_STATE["kitchen_preparing"],
                "Kitchen Preparing",
                "The kitchen is preparing your order.",
                "badge-preparing",
                "bi-fire",
            ),
            "kitchen_ready": (
                self.GUEST_PROGRESS_STEP_BY_STATE["kitchen_ready"],
                "Ready for Delivery",
                "Your order is ready and waiting for Room Service delivery.",
                "badge-ready",
                "bi-bag-check-fill",
            ),
            "delivered": (
                self.GUEST_PROGRESS_STEP_BY_STATE["delivered"],
                "Delivered — Completion Pending",
                "Your order was delivered. Room Service will complete billing after the signed receipt is returned.",
                "badge-ready",
                "bi-door-open-fill",
            ),
            "guest_confirmed": (
                self.GUEST_PROGRESS_STEP_BY_STATE["guest_confirmed"],
                "Delivery Recorded",
                "Room Service is completing the signed receipt and room charge.",
                "badge-ready",
                "bi-door-open-fill",
            ),
            "folio_posted": (
                self.GUEST_PROGRESS_STEP_BY_STATE["folio_posted"],
                "Completed & Billed",
                "The final charge was posted to your room folio.",
                "badge-delivered",
                "bi-check-circle-fill",
            ),
            "paid_pos": (
                self.GUEST_PROGRESS_STEP_BY_STATE["paid_pos"],
                "Completed",
                "This order is complete.",
                "badge-delivered",
                "bi-check-circle-fill",
            ),
            "closed": (
                self.GUEST_PROGRESS_STEP_BY_STATE["closed"],
                "Completed",
                "This order is complete.",
                "badge-delivered",
                "bi-check-circle-fill",
            ),
            "cancelled": (
                self.GUEST_PROGRESS_STEP_BY_STATE["cancelled"],
                "Cancelled",
                "This order was cancelled.",
                "badge-cancelled",
                "bi-x-circle-fill",
            ),
        }
        step, step_title, step_desc, badge_class, icon = status_by_state.get(
            state,
            (0, state.replace("_", " ").title(), "Room Service is processing your order.", "badge-confirmed", "bi-clock-fill"),
        )

        display_tz = self._get_guest_display_timezone(order)
        local_created = fields.Datetime.context_timestamp(
            request.env.user.with_context(tz=display_tz),
            order.create_date or fields.Datetime.now(),
        )

        lines_data = []
        for line in order.line_ids:
            quantity = float(line.quantity or 0.0)
            display_quantity = int(quantity) if quantity.is_integer() else quantity
            lines_data.append({
                "name": line.name or line.product_id.display_name,
                "quantity": display_quantity,
                "price_subtotal": float(line.subtotal or 0.0),
            })

        return {
            "id": order.id,
            "name": order.name,
            "state": state,
            "state_label": dict(order._fields["state"].selection).get(state, state),
            "step": step,
            "step_title": step_title,
            "step_desc": step_desc,
            "badge_class": badge_class,
            "icon": icon,
            "is_final": state in self.GUEST_FINAL_STATES,
            "total_amount": float(order.total_amount or 0.0),
            "currency_symbol": currency.symbol or "$",
            "created_date_str": local_created.strftime("%b %d, %Y"),
            "created_time_str": local_created.strftime("%I:%M %p"),
            "requested_delivery_time": order.requested_delivery_time or "ASAP",
            "payment_method_label": (
                "Bill to Room" if order.payment_method == "bill_to_room" else "Pay at Outlet"
            ),
            "lines": lines_data,
            "item_count": sum(float(line.quantity or 0.0) for line in order.line_ids),
        }

    def _get_guest_display_timezone(self, order):
        """Use hotel-local time; never inherit the public website user's timezone."""
        return (
            order.reservation_id.company_id.partner_id.tz
            or "Asia/Phnom_Penh"
        )

    def _guest_orders(self, reservation):
        return request.env["hotel.room.service.order"].sudo().search(
            [
                ("reservation_id", "=", reservation.id),
                ("guest_submitted", "=", True),
            ],
            order="create_date desc, id desc",
        )

    @http.route(
        "/room-service/<string:token>/orders/json",
        type="jsonrpc",
        auth="public",
        website=True,
        methods=["POST"],
        csrf=True,
    )
    def room_service_orders_json(self, token, **kw):
        token_record = self._get_token_record(token, touch=False)
        if not token_record:
            return {"success": False, "error": "Invalid or inactive room QR code.", "orders": []}

        reservation = token_record._get_active_reservation()
        if not reservation:
            return {"success": False, "error": "No active in-house reservation.", "orders": []}

        orders = self._guest_orders(reservation)
        return {
            "success": True,
            "orders": [self._serialize_guest_order(order) for order in orders],
        }

    @http.route(
        "/room-service/<string:token>/place-order/json",
        type="jsonrpc",
        auth="public",
        website=True,
        methods=["POST"],
        csrf=True,
    )
    def room_service_place_order_json(
        self,
        token,
        cart=None,
        requested_delivery_time="ASAP",
        guest_note="",
        client_order_key=None,
        **kw,
    ):
        token_record = self._get_token_record(token)
        if not token_record:
            return {"success": False, "error": "This room service QR code is invalid or inactive."}

        reservation = token_record._get_active_reservation()
        if not reservation:
            return {
                "success": False,
                "error": "No active in-house guest was found for this room. Please contact Front Desk.",
            }

        request_key = str(client_order_key or "").strip()
        if (
            not request_key
            or len(request_key) > 64
            or any(not (char.isalnum() or char in "-_") for char in request_key)
        ):
            return {"success": False, "error": "The order request identifier is invalid. Please refresh and try again."}

        Order = request.env["hotel.room.service.order"].sudo()
        existing_order = Order.search(
            [
                ("reservation_id", "=", reservation.id),
                ("guest_request_key", "=", request_key),
            ],
            limit=1,
        )
        if existing_order:
            return {
                "success": True,
                "duplicate_prevented": True,
                "order": self._serialize_guest_order(existing_order),
                "message": "This order was already received. No duplicate was created.",
            }

        if not isinstance(cart, list) or not cart or len(cart) > 50:
            return {"success": False, "error": "Select between 1 and 50 menu items."}

        requested_items = {}
        try:
            for item in cart:
                product_id = int(item.get("product_id") or 0)
                quantity = float(item.get("qty") or 0.0)
                if product_id <= 0 or quantity <= 0 or quantity > 99:
                    raise ValueError
                note = str(item.get("note") or "").strip()[:500]
                allergens = item.get("allergens") or ""
                if isinstance(allergens, list):
                    allergens = ", ".join(str(value) for value in allergens)
                allergens = str(allergens).strip()[:500]
                if product_id in requested_items:
                    requested_items[product_id]["quantity"] += quantity
                    if requested_items[product_id]["quantity"] > 99:
                        raise ValueError
                else:
                    requested_items[product_id] = {
                        "quantity": quantity,
                        "note": note,
                        "allergens": allergens,
                    }
        except (AttributeError, TypeError, ValueError):
            return {"success": False, "error": "One or more order items are invalid."}

        outlets = request.env["hotel.room.service.outlet"].sudo().search(
            [("active", "=", True)],
            order="sequence, id",
        )
        outlet = request.env["hotel.room.service.outlet"].sudo()
        allowed_products = {}
        requested_product_ids = set(requested_items)
        for candidate_outlet in outlets:
            candidate_products = {
                product.id: product
                for product in candidate_outlet._get_pos_menu_products()
            }
            if requested_product_ids.issubset(candidate_products):
                outlet = candidate_outlet
                allowed_products = candidate_products
                break

        if not outlet:
            return {
                "success": False,
                "error": "The selected items are unavailable or belong to different outlets. Please refresh the menu.",
            }

        order_lines = []
        for product_id, item in requested_items.items():
            product = allowed_products[product_id]
            quantity = item["quantity"]
            order_lines.append((0, 0, {
                "product_id": product.id,
                "name": product.display_name,
                "quantity": quantity,
                "price_unit": outlet._get_pos_product_price(product, quantity),
                "note": item["note"],
                "allergen_flags": item["allergens"],
            }))

        order_values = {
            "token_id": token_record.id,
            "reservation_id": reservation.id,
            "outlet_id": outlet.id,
            "payment_method": "bill_to_room",
            "guest_submitted": False,
            "guest_request_key": request_key,
            "requested_delivery_time": str(requested_delivery_time or "ASAP").strip()[:100],
            "guest_note": str(guest_note or "").strip()[:2000],
            "line_ids": order_lines,
        }

        try:
            with request.env.cr.savepoint():
                order = Order.create(order_values)
                order.action_guest_submit()
        except IntegrityError:
            order = Order.search(
                [
                    ("reservation_id", "=", reservation.id),
                    ("guest_request_key", "=", request_key),
                ],
                limit=1,
            )
            if not order:
                return {"success": False, "error": "The order could not be saved. Please contact Room Service."}
        except Exception as exc:
            return {"success": False, "error": str(exc)}

        return {
            "success": True,
            "order": self._serialize_guest_order(order),
            "message": "Your order was submitted to Room Service for review.",
        }

    def _get_monitor_summary(self, orders):
        return {
            "awaiting_confirmation": len(orders.filtered(lambda order: order.state == "draft")),
            "waiting": len(orders.filtered(lambda order: order.state in ["confirmed", "sent_pos", "pos_failed"])),
            "preparing": len(orders.filtered(lambda order: order.state == "kitchen_preparing")),
            "ready": len(orders.filtered(lambda order: order.state in ["kitchen_ready", "delivered", "guest_confirmed"])),
            "completed": len(orders.filtered(lambda order: order.state in self.MONITOR_TERMINAL_STATES)),
        }

    def _get_monitor_domain(self):
        business_date = request.env.company.hotel_business_date or fields.Date.context_today(request.env.user)
        return [
            ("guest_submitted", "=", True),
            "|",
            ("state", "in", self.MONITOR_ACTIVE_STATES),
            "&",
            ("state", "in", self.MONITOR_TERMINAL_STATES),
            ("hotel_business_date", "=", business_date),
        ]

    def _get_monitor_menu_payload(self, outlet):
        return self._get_monitor_change_payload(outlet)

    def _get_monitor_created_payload(self, order, now):
        created_at = order.create_date
        if not created_at:
            return {
                "date_utc": "",
                "date_str": "",
                "time_str": "",
                "wait_minutes": 0,
            }
        display_tz = (
            request.env.context.get("tz")
            or request.env.user.tz
            or request.env.company.partner_id.tz
            or "Asia/Phnom_Penh"
        )
        local_created_at = fields.Datetime.context_timestamp(
            request.env.user.with_context(tz=display_tz),
            created_at,
        )
        final_state = order.state in self.MONITOR_TERMINAL_STATES or order.state == "cancelled"
        end_at = (order.completed_at or order.closed_at or order.folio_posted_at or now) if final_state else now
        return {
            "date_utc": created_at.isoformat() + "Z",
            "date_str": local_created_at.strftime("%Y-%m-%d %H:%M"),
            "time_str": local_created_at.strftime("%I:%M %p"),
            "wait_minutes": max(0, int((end_at - created_at).total_seconds() // 60)),
            "wait_is_final": bool(final_state),
        }

    def _get_monitor_change_payload(self, outlet):
        """Build the staff selector from the exact same Product catalog as the guest QR menu."""
        if not outlet:
            outlet = request.env["hotel.room.service.outlet"].sudo().search([], limit=1)
        if not outlet:
            return [], []

        guest_catalog = outlet.get_pos_menu_payload()

        item_payloads = []
        categories_by_name = {}
        for guest_item in guest_catalog.get("items", []):
            category_name = guest_item["category"]
            cat_key = category_name.strip()
            if cat_key not in categories_by_name:
                categories_by_name[cat_key] = {
                    "id": len(categories_by_name) + 1,
                    "name": category_name,
                    "items": [],
                }
            cat_payload = categories_by_name[cat_key]

            product_id = guest_item["product_id"]
            item_payload = {
                "id": -product_id,
                "menu_item_id": False,
                "product_id": product_id,
                "name": guest_item["name"],
                "price": guest_item["price"],
                "description": guest_item["description"],
                "category_id": cat_payload["id"],
                "category_name": category_name,
                "image_url": guest_item["image_url"],
                "has_image": guest_item["has_image"],
            }
            item_payloads.append(item_payload)
            cat_payload["items"].append(item_payload)
        return item_payloads, list(categories_by_name.values())

    def _get_valid_monitor_item(self, order, menu_item_id=None, product_id=None):
        MenuItem = request.env["hotel.room.service.menu.item"].sudo()
        Product = request.env["product.product"].sudo()
        menu_item = MenuItem
        product = Product

        menu_item_id = int(menu_item_id or 0)
        product_id = int(product_id or 0)
        if menu_item_id:
            menu_item = MenuItem.browse(menu_item_id).exists()
            if not menu_item or not menu_item.active or menu_item.outlet_id != order.outlet_id:
                raise ValueError(_("Selected menu item is not active for this outlet."))
        if product_id:
            product = Product.browse(product_id).exists()
            if not product:
                raise ValueError(_("Selected product was not found."))
        if menu_item:
            if product and product != menu_item.product_id:
                raise ValueError(_("Selected menu item and product do not match."))
            product = menu_item.product_id

        allowed_products = order.outlet_id._get_pos_menu_products()
        if not product or product not in allowed_products:
            raise ValueError(_("Selected product is not enabled for this Room Service outlet."))
        return menu_item, product

    def _reconcile_monitor_kitchen_orders(self):
        orders = request.env["hotel.room.service.order"].search([
            ("guest_submitted", "=", True),
            ("state", "in", self.DISPLAY_STATES),
            ("pos_order_id", "!=", False),
        ])
        orders._reconcile_pos_kitchen_status()

    def _get_monitor_order_number(self, order):
        """Use full order reference (e.g. 260-2-000001) for Room Service Monitor display."""
        pos_order = order.pos_order_id.sudo()
        if pos_order and pos_order.pos_reference:
            return pos_order.pos_reference
        return order.pos_reference or order.name

    def _get_monitor_guest_phone(self, order):
        partner = order.partner_id.sudo()
        return getattr(partner, "mobile", False) or getattr(partner, "phone", False) or ""

    def _get_token_record(self, token, touch=True):
        token_record = request.env["hotel.room.service.room.token"].sudo().search(
            [("token", "=", token), ("active", "=", True)],
            limit=1,
        )
        if token_record and touch:
            token_record.sudo().write({"last_scanned_at": fields.Datetime.now()})
        return token_record

    def _render_error(self, message, status=200):
        return request.render("hotel_room_service_qr.room_service_error", {"message": message}, status=status)

    def _get_qr_download_tokens(self, ids=None, download_all=False):
        Token = request.env["hotel.room.service.room.token"]
        if download_all:
            return Token.search([("active", "=", True)], order="room_id")
        token_ids = []
        for raw_id in (ids or "").split(","):
            if raw_id.strip().isdigit():
                token_ids.append(int(raw_id.strip()))
        return Token.browse(token_ids).exists()

    @http.route("/room-service/qr/<int:token_id>/download.png", type="http", auth="user")
    def room_service_qr_download_png(self, token_id, **kw):
        _require_room_service_staff()
        token = request.env["hotel.room.service.room.token"].browse(token_id).exists()
        if not token:
            return request.not_found()
        png_data = token._get_qr_png_bytes()
        return request.make_response(
            png_data,
            headers=[
                ("Content-Type", "image/png"),
                ("Content-Length", str(len(png_data))),
                ("Content-Disposition", content_disposition(token._get_qr_filename("png"))),
            ],
        )

    @http.route("/room-service/qr/download.zip", type="http", auth="user")
    def room_service_qr_download_zip(self, ids=None, all=None, **kw):
        _require_room_service_staff()
        tokens = self._get_qr_download_tokens(ids=ids, download_all=bool(all))
        if not tokens:
            return request.not_found()

        buffer = BytesIO()
        used_names = set()
        with zipfile.ZipFile(buffer, "w", zipfile.ZIP_DEFLATED) as archive:
            for token in tokens:
                filename = token._get_qr_filename("png")
                if filename in used_names:
                    filename = "room-service-qr-room-%s-%s.png" % (token.room_number or token.id, token.id)
                used_names.add(filename)
                archive.writestr(filename, token._get_qr_png_bytes())

        zip_data = buffer.getvalue()
        return request.make_response(
            zip_data,
            headers=[
                ("Content-Type", "application/zip"),
                ("Content-Length", str(len(zip_data))),
                ("Content-Disposition", content_disposition("room-service-qr-codes.zip")),
            ],
        )

    @http.route("/room-service/order-display", type="http", auth="user")
    def room_service_order_display(self, **kw):
        _require_room_service_staff()
        Order = request.env["hotel.room.service.order"]
        self._reconcile_monitor_kitchen_orders()
        state_labels = dict(Order._fields["state"].selection)
        now = fields.Datetime.now()

        orders = Order.search(self._get_monitor_domain(), order="create_date asc, id asc")
        summary = self._get_monitor_summary(orders)
        orders_data = []
        for order in orders:
            lines = []
            total_items = 0
            for line in order.line_ids:
                total_items += line.quantity
                lines.append({
                    'id': line.id,
                    'menu_item_id': line.menu_item_id.id,
                    'product_id': line.product_id.id,
                    'name': line.name or line.product_id.display_name,
                    'qty': line.quantity,
                    'price_unit': line.price_unit,
                    'subtotal': line.subtotal,
                    'note': line.note or '',
                })
            menu_items, menu_categories = self._get_monitor_menu_payload(order.outlet_id)
            change_items, change_categories = self._get_monitor_change_payload(order.outlet_id)
            created_payload = self._get_monitor_created_payload(order, now)
            orders_data.append({
                'id': order.id,
                'number': self._get_monitor_order_number(order),
                'name': order.name,
                'room': order.room_number or '-',
                'guest': order.partner_id.name or '',
                'guest_phone': self._get_monitor_guest_phone(order),
                'state': order.state,
                'state_label': state_labels.get(order.state, order.state),
                'status_group': self._get_monitor_status_group(order.state),
                'date_utc': created_payload["date_utc"],
                'date_str': created_payload["date_str"],
                'time_str': created_payload["time_str"],
                'wait_minutes': created_payload["wait_minutes"],
                'wait_is_final': created_payload["wait_is_final"],
                'total_items': total_items,
                'total': order.total_amount,
                'lines': lines,
                'can_edit_items': order.state == 'draft' and order.guest_submitted,
                'menu_items': menu_items,
                'menu_categories': menu_categories,
                'change_items': change_items,
                'change_categories': change_categories,
                'note': order.guest_note or '',
                'payment': order.payment_method,
            })
        closed_sessions = []
        outlets = request.env["hotel.room.service.outlet"].sudo().search([("active", "=", True)])
        for outlet in outlets:
            if outlet.auto_create_pos_order and outlet.pos_config_id:
                session = request.env["pos.session"].sudo().search(
                    [("config_id", "=", outlet.pos_config_id.id), ("state", "=", "opened")],
                    limit=1,
                )
                if not session:
                    closed_sessions.append(outlet.name)

        return request.render(
            "hotel_room_service_qr.room_service_order_display",
            {
                "current_order": orders[:1],
                "queue_orders": orders[1:],
                "state_labels": state_labels,
                "orders_data": orders_data,
                "orders_data_json": json.dumps(orders_data),
                "summary": summary,
                "summary_json": json.dumps(summary),
                "closed_sessions": closed_sessions,
                "closed_sessions_json": json.dumps(closed_sessions),
            },
        )

    def _get_monitor_status_group(self, state):
        if state == "draft":
            return "awaiting_confirmation"
        if state in ["confirmed", "sent_pos", "pos_failed"]:
            return "waiting"
        if state == "kitchen_preparing":
            return "preparing"
        if state in ["kitchen_ready", "delivered", "guest_confirmed"]:
            return "ready"
        return "completed"

    def _get_tracker_steps(self, order):
        state_to_index = {
            "draft": 0,
            "confirmed": 1,
            "sent_pos": 2,
            "pos_failed": 2,
            "kitchen_preparing": 3,
            "kitchen_ready": 4,
            "delivered": 5,
            "guest_confirmed": 6,
            "folio_posted": 6,
            "paid_pos": 6,
            "closed": 6,
        }
        steps = [
            ("placed", "Order Placed"),
            ("confirmed", "Confirmed"),
            ("sent_pos", "Sent to Kitchen"),
            ("cooking", "Cooking"),
            ("ready", "Ready to Deliver"),
            ("delivered", "Delivered"),
            ("completed", "Completed"),
        ]
        current_index = state_to_index.get(order.state, 0)
        cancelled = order.state == "cancelled"
        result = []
        for index, (key, label) in enumerate(steps):
            if cancelled:
                step_state = "future"
            elif index < current_index:
                step_state = "done"
            elif index == current_index:
                step_state = "current"
            else:
                step_state = "future"
            result.append({"key": key, "label": label, "state": step_state})
        if cancelled:
            result.append({"key": "cancelled", "label": "Cancelled", "state": "cancelled"})
        return result

    def _get_tracker_payload(self, order):
        order = order.sudo()
        state_labels = dict(order._fields["state"].selection)
        customer_state_labels = {
            "draft": "Awaiting Staff Review",
        }
        return {
            "id": order.id,
            "access_token": order.access_token or "",
            "pos_order_access_token": order.pos_order_id.access_token or "",
            "name": order.name or "",
            "number": self._get_monitor_order_number(order),
            "room": order.room_number or "",
            "guest": order.partner_id.name or "",
            "state": order.state,
            "state_label": customer_state_labels.get(
                order.state, state_labels.get(order.state, order.state)
            ),
            "last_error": order.last_error or "",
            "updated_at": order.write_date.strftime("%Y-%m-%d %H:%M:%S") if order.write_date else "",
            "updated_at_display": order.write_date.strftime("%b %d, %I:%M %p") if order.write_date else "",
            "steps": self._get_tracker_steps(order),
        }

    def _get_latest_room_service_order_for_pos_self(self, pos_order_access_tokens=None, room_service_token=None, table_identifier=None):
        Order = request.env["hotel.room.service.order"].sudo()
        orders = Order.browse()
        pos_order_access_tokens = [token for token in (pos_order_access_tokens or []) if token]
        if pos_order_access_tokens:
            pos_orders = request.env["pos.order"].sudo().search([("access_token", "in", pos_order_access_tokens)])
            if pos_orders:
                orders = Order.search(
                    [("pos_order_id", "in", pos_orders.ids)],
                    order="create_date desc, id desc",
                )

        token_record = False
        room = False
        if room_service_token:
            token_record = request.env["hotel.room.service.room.token"].sudo().search(
                [("token", "=", room_service_token), ("active", "=", True)],
                limit=1,
            )
            room = token_record.room_id

        if not room and table_identifier:
            table = request.env["restaurant.table"].sudo().search([("identifier", "=", table_identifier)], limit=1)
            room = table.room_id if table else False

        if not room and token_record:
            room = token_record.room_id

        if room:
            reservation = token_record._get_active_reservation() if token_record else False
            if reservation:
                orders |= Order.search(
                    [
                        ("room_id", "=", room.id),
                        ("reservation_id", "=", reservation.id),
                        ("guest_submitted", "=", True),
                    ],
                    order="create_date desc, id desc",
                    limit=1,
                )
        elif token_record:
            reservation = token_record._get_active_reservation()
            if reservation:
                orders |= Order.search(
                    [
                        ("token_id", "=", token_record.id),
                        ("reservation_id", "=", reservation.id),
                        ("guest_submitted", "=", True),
                    ],
                    order="create_date desc, id desc",
                    limit=1,
                )
        return orders.sorted(lambda order: (order.create_date, order.id), reverse=True)

    @http.route("/room-service/pos-self/tracker/json", type="jsonrpc", auth="public", website=True)
    def room_service_pos_self_tracker_json(self, pos_order_access_tokens=None, room_service_token=None, table_identifier=None, **kw):
        Order = request.env["hotel.room.service.order"].sudo()
        orders = Order.browse()
        scope_room = False

        # A Room Service QR token is the authoritative browser-data boundary.  Never trust
        # POS access tokens supplied from local storage until they have been scoped to the
        # room token that was scanned for this request.
        token_record = False
        if room_service_token:
            token_record = request.env["hotel.room.service.room.token"].sudo().search(
                [("token", "=", room_service_token), ("active", "=", True)], limit=1
            )
        if token_record:
            scope_room = token_record.room_id
            reservation = token_record._get_active_reservation()
            if reservation:
                orders = Order.search(
                    [
                        ("token_id", "=", token_record.id),
                        ("reservation_id", "=", reservation.id),
                        ("guest_submitted", "=", True),
                    ],
                    order="create_date desc, id desc",
                )
        elif table_identifier:
            table = request.env["restaurant.table"].sudo().search(
                [("identifier", "=", table_identifier)], limit=1
            )
            scope_room = table.room_id if table else False
            if scope_room:
                token_for_room = request.env["hotel.room.service.room.token"].sudo().search(
                    [("room_id", "=", scope_room.id), ("active", "=", True)], limit=1
                )
                reservation = token_for_room._get_active_reservation() if token_for_room else False
                if reservation:
                    orders = Order.search(
                        [
                            ("room_id", "=", scope_room.id),
                            ("reservation_id", "=", reservation.id),
                            ("guest_submitted", "=", True),
                        ],
                        order="create_date desc, id desc",
                    )
        elif pos_order_access_tokens:
            # Retain the generic POS-self tracker behavior outside a Room Service QR session.
            orders = self._get_latest_room_service_order_for_pos_self(
                pos_order_access_tokens=pos_order_access_tokens,
            )

        trackers_by_pos_token = {}
        latest = False
        for order in orders:
            payload = self._get_tracker_payload(order)
            if order.pos_order_id.access_token:
                trackers_by_pos_token[order.pos_order_id.access_token] = payload
            if not latest:
                latest = payload
        return {
            "has_order": bool(orders),
            "latest": latest or {},
            "orders": trackers_by_pos_token,
            "allowed_pos_order_tokens": list(trackers_by_pos_token),
            "room": scope_room.name if scope_room else "",
        }

    def _get_room_status_payload(self):
        Room = request.env["hotel.room"].sudo()
        Reservation = request.env["hotel.reservation"].sudo()
        Order = request.env["hotel.room.service.order"].sudo()
        order_labels = dict(Order._fields["state"].selection)
        biz_date = request.env.company.hotel_business_date or fields.Date.context_today(request.env.user)

        rooms = Room.search([], order="zone_id, floor_id, name")
        active_orders = Order.search(
            [
                ("room_id", "in", rooms.ids),
                ("guest_submitted", "=", True),
                ("state", "in", self.ROOM_STATUS_ACTIVE_STATES),
            ],
            order="create_date desc, id desc",
        )
        order_by_room = {}
        for order in active_orders:
            if order.room_id.id not in order_by_room:
                order_by_room[order.room_id.id] = order

        inhouse_reservations = Reservation.search(
            [
                ("room_id", "in", rooms.ids),
                ("state", "in", ["checkin", "checkout_hold"]),
                ("checkin_date", "<=", biz_date),
                ("company_id", "in", request.env.companies.ids),
            ],
            order="id desc",
        )
        reservation_by_room = {}
        for reservation in inhouse_reservations:
            if reservation.room_id.id not in reservation_by_room:
                reservation_by_room[reservation.room_id.id] = reservation

        rooms_data = []
        zones = {}
        floors = {}
        for room in rooms:
            order = order_by_room.get(room.id)
            reservation = reservation_by_room.get(room.id)
            zone_name = room.zone_id.name or "No Building"
            floor_name = room.floor_id.display_name or room.floor_id.name or "No Floor"
            zones[zone_name] = zone_name
            floors[floor_name] = floor_name
            rooms_data.append(
                {
                    "id": room.id,
                    "number": room.name or "",
                    "type": room.room_type_id.name or "",
                    "zone": zone_name,
                    "floor": floor_name,
                    "guest": reservation.partner_id.name if reservation else "",
                    "has_order": bool(order),
                    "order_id": order.id if order else False,
                    "order_name": order.name if order else "",
                    "order_status": order_labels.get(order.state, order.state) if order else "",
                    "order_state": order.state if order else "",
                    "order_url": "/web#id=%s&model=hotel.room.service.order&view_type=form" % order.id if order else "",
                    "room_orders_url": "/web#model=hotel.room.service.order&view_type=list&domain=%s"
                    % json.dumps([["room_id", "=", room.id]]),
                }
            )
        return {
            "rooms": rooms_data,
            "zones": sorted(zones),
            "floors": sorted(floors),
            "summary": {
                "total": len(rooms_data),
                "ordered": len([room for room in rooms_data if room["has_order"]]),
                "no_order": len([room for room in rooms_data if not room["has_order"]]),
            },
        }

    @http.route("/room-service/room-status", type="http", auth="user")
    def room_service_room_status(self, **kw):
        _require_room_service_staff()
        payload = self._get_room_status_payload()
        return request.render(
            "hotel_room_service_qr.room_service_room_status",
            {
                "rooms_data_json": json.dumps(payload["rooms"]),
                "zones_json": json.dumps(payload["zones"]),
                "floors_json": json.dumps(payload["floors"]),
                "summary_json": json.dumps(payload["summary"]),
            },
        )

    @http.route("/room-service/room-status/json", type="jsonrpc", auth="user", methods=["POST"], csrf=True)
    def room_service_room_status_json(self, **kw):
        _require_room_service_staff()
        return self._get_room_status_payload()

    @http.route("/room-service/order-display/<int:order_id>/<string:action_name>", type="http", auth="user", methods=["POST"], csrf=True)
    def room_service_monitor_action(self, order_id, action_name, **post):
        _require_room_service_staff()
        order = request.env["hotel.room.service.order"].browse(order_id).exists()
        if not order:
            return request.not_found()
        if action_name == "accept":
            order.action_confirm_to_pos()
        elif action_name == "cancel":
            order.action_cancel_before_pos()
        elif action_name == "preparing":
            order.action_kitchen_preparing()
        elif action_name == "ready":
            order.action_kitchen_ready()
        elif action_name == "delivered":
            order.action_delivered()
        elif action_name == "complete":
            order.action_complete_and_post()
        return request.redirect("/room-service/order-display")

    @http.route("/room-service/order-display/json", type="jsonrpc", auth="user", methods=["POST"], csrf=True)
    def room_service_order_display_json(self, **kw):
        _require_room_service_staff()
        Order = request.env["hotel.room.service.order"]
        self._reconcile_monitor_kitchen_orders()
        state_labels = dict(Order._fields["state"].selection)
        now = fields.Datetime.now()

        orders = Order.search(self._get_monitor_domain(), order="create_date asc, id asc")
        summary = self._get_monitor_summary(orders)
        orders_data = []
        for order in orders:
            lines = []
            total_items = 0
            for line in order.line_ids:
                total_items += line.quantity
                lines.append({
                    'id': line.id,
                    'menu_item_id': line.menu_item_id.id,
                    'product_id': line.product_id.id,
                    'name': line.name or line.product_id.display_name,
                    'qty': line.quantity,
                    'price_unit': line.price_unit,
                    'subtotal': line.subtotal,
                    'note': line.note or '',
                })
            menu_items, menu_categories = self._get_monitor_menu_payload(order.outlet_id)
            change_items, change_categories = self._get_monitor_change_payload(order.outlet_id)
            created_payload = self._get_monitor_created_payload(order, now)
            orders_data.append({
                'id': order.id,
                'number': self._get_monitor_order_number(order),
                'name': order.name,
                'room': order.room_number or '-',
                'guest': order.partner_id.name or '',
                'guest_phone': self._get_monitor_guest_phone(order),
                'state': order.state,
                'state_label': state_labels.get(order.state, order.state),
                'status_group': self._get_monitor_status_group(order.state),
                'date_utc': created_payload["date_utc"],
                'date_str': created_payload["date_str"],
                'time_str': created_payload["time_str"],
                'wait_minutes': created_payload["wait_minutes"],
                'wait_is_final': created_payload["wait_is_final"],
                'total_items': total_items,
                'total': order.total_amount,
                'lines': lines,
                'can_edit_items': order.state == 'draft' and order.guest_submitted,
                'menu_items': menu_items,
                'menu_categories': menu_categories,
                'change_items': change_items,
                'change_categories': change_categories,
                'note': order.guest_note or '',
                'payment': order.payment_method,
            })
        closed_sessions = []
        outlets = request.env["hotel.room.service.outlet"].sudo().search([("active", "=", True)])
        for outlet in outlets:
            if outlet.auto_create_pos_order and outlet.pos_config_id:
                session = request.env["pos.session"].sudo().search(
                    [("config_id", "=", outlet.pos_config_id.id), ("state", "=", "opened")],
                    limit=1,
                )
                if not session:
                    closed_sessions.append(outlet.name)

        return {
            "orders": orders_data,
            "summary": summary,
            "closed_sessions": closed_sessions,
        }

    @http.route("/room-service/order-display/edit-line/json", type="jsonrpc", auth="user", methods=["POST"], csrf=True)
    def room_service_monitor_edit_line_json(
        self, order_id, operation, line_id=None, menu_item_id=None,
        product_id=None, quantity=None, **post
    ):
        _require_room_service_staff()
        order = request.env["hotel.room.service.order"].browse(int(order_id or 0)).exists()
        if not order:
            return {"success": False, "error": "Order not found."}
        if order.state != "draft" or not order.guest_submitted:
            return {"success": False, "error": "Order items can only be edited before the order is accepted."}

        try:
            Line = request.env["hotel.room.service.order.line"]
            if operation == "update_qty":
                line = Line.browse(int(line_id or 0)).exists()
                if not line or line.order_id.id != order.id:
                    return {"success": False, "error": "Order line not found."}
                qty = float(quantity or 0)
                if qty <= 0:
                    line.unlink()
                else:
                    line.write({"quantity": qty})
            elif operation == "remove":
                line = Line.browse(int(line_id or 0)).exists()
                if not line or line.order_id.id != order.id:
                    return {"success": False, "error": "Order line not found."}
                line.unlink()
            elif operation == "add":
                menu_item, product = self._get_valid_monitor_item(
                    order, menu_item_id=menu_item_id, product_id=product_id
                )

                qty = float(quantity or 1)
                if qty <= 0:
                    return {"success": False, "error": "Quantity must be greater than zero."}

                existing = order.line_ids.filtered(
                    lambda line: line.product_id.id == product.id
                )[:1]
                if existing:
                    existing.write({"quantity": existing.quantity + qty})
                else:
                    Line.create({
                        "order_id": order.id,
                        "menu_item_id": False,
                        "product_id": product.id,
                        "name": product.display_name,
                        "quantity": qty,
                        "price_unit": order.outlet_id._get_pos_product_price(product),
                    })
            elif operation == "change":
                line = Line.browse(int(line_id or 0)).exists()
                if not line or line.order_id.id != order.id:
                    return {"success": False, "error": "Order line not found."}
                
                menu_item, product = self._get_valid_monitor_item(
                    order, menu_item_id=menu_item_id, product_id=product_id
                )

                qty = float(quantity or line.quantity or 1)
                if qty <= 0:
                    return {"success": False, "error": "Quantity must be greater than zero."}
                line.write({
                    "menu_item_id": False,
                    "product_id": product.id,
                    "name": product.display_name,
                    "quantity": qty,
                    "price_unit": order.outlet_id._get_pos_product_price(product),
                })
            else:
                return {"success": False, "error": "Unsupported edit operation."}
            order._log_adapter(
                "system",
                "success",
                _("Room-service staff %(user)s adjusted order items (%(operation)s).") % {
                    "user": request.env.user.display_name,
                    "operation": operation,
                },
            )
            return {"success": True}
        except Exception as e:
            return {"success": False, "error": str(e)}

    @http.route("/room-service/order-display/action/json", type="jsonrpc", auth="user", methods=["POST"], csrf=True)
    def room_service_monitor_action_json(self, order_id, action_name, **post):
        _require_room_service_staff()
        order = request.env["hotel.room.service.order"].browse(order_id).exists()
        if not order:
            return {"success": False, "error": "Order not found."}
        try:
            if action_name == "accept":
                order.action_confirm_to_pos()
            elif action_name == "cancel":
                order.action_cancel_before_pos()
            elif action_name == "preparing":
                order.action_kitchen_preparing()
            elif action_name == "ready":
                order.action_kitchen_ready()
            elif action_name == "delivered":
                order.action_delivered()
            elif action_name == "complete":
                order.action_complete_and_post()
            else:
                return {"success": False, "error": "Unsupported action."}
            return {"success": True}
        except Exception as e:
            return {"success": False, "error": str(e)}

    @http.route("/hotel/room-service/<string:reservation_token>", type="http", auth="public", website=True)
    def room_service_from_booking(self, reservation_token, **kw):
        """Allow guests to access room service directly from their booking confirmation page."""
        reservation = request.env["hotel.reservation"].sudo().search(
            [("access_token", "=", reservation_token)], limit=1
        )
        if not reservation:
            return self._render_error("Reservation not found. Please check your booking link.", status=404)

        if not reservation.room_id:
            return self._render_error("No room is assigned to this reservation yet. Please contact the front desk.")

        # Find the room's QR token
        token_record = request.env["hotel.room.service.room.token"].sudo().search(
            [("room_id", "=", reservation.room_id.id), ("active", "=", True)], limit=1
        )
        if not token_record:
            return self._render_error(
                "Room service is not yet configured for this room. Please contact the front desk."
            )

        # Redirect to the standard room-service menu URL
        return request.redirect("/room-service/%s" % token_record.token)

    @http.route("/room-service/<string:token>", type="http", auth="public", website=True)
    def room_service_menu(self, token, **kw):
        token_record = self._get_token_record(token)
        if not token_record:
            return self._render_error("This room service QR code is invalid or inactive.", status=404)

        reservation = token_record._get_active_reservation()
        if not reservation:
            return self._render_error("No active in-house guest was found for this room. Please contact Front Desk.")

        outlets = request.env["hotel.room.service.outlet"].sudo().search([("active", "=", True)])
        if not outlets:
            return self._render_error(
                "Room service ordering is not yet configured. Please contact the front desk."
            )

        # Keep Room Service QR ordering in the hotel-controlled Bill-to-Room
        # flow.  POS is still used as the kitchen adapter after staff review.
        menu_payloads = []
        for outlet in outlets:
            payload = outlet.get_pos_menu_payload()
            if payload.get("items"):
                payload["outlet"] = outlet
                menu_payloads.append(payload)

        currency = reservation.currency_id or request.env.company.currency_id
        guest_orders = [
            self._serialize_guest_order(order)
            for order in self._guest_orders(reservation)
        ]
        return request.render(
            "hotel_room_service_qr.room_service_menu",
            {
                "token": token_record.token,
                "room": token_record.room_id,
                "reservation": reservation,
                "menu_payloads": menu_payloads,
                "currency_symbol": currency.symbol or "$",
                "currency_position": currency.position or "before",
                "guest_orders": guest_orders,
                "active_orders_count": len([
                    order for order in guest_orders if not order["is_final"]
                ]),
            },
        )

    @http.route("/room-service/<string:token>/review", type="http", auth="public", website=True, methods=["POST"], csrf=True)
    def room_service_review(self, token, **post):
        token_record = self._get_token_record(token)
        if not token_record:
            return self._render_error("This room service QR code is invalid or inactive.", status=404)

        reservation = token_record._get_active_reservation()
        if not reservation:
            return self._render_error("No active in-house guest was found for this room. Please contact Front Desk.")

        selected_lines = []
        outlet = request.env["hotel.room.service.outlet"].sudo()
        outlets = request.env["hotel.room.service.outlet"].sudo().search([("active", "=", True)])
        for candidate_outlet in outlets:
            allowed_products = candidate_outlet._get_pos_menu_products()
            for product in allowed_products:
                field_key = "%s_%s" % (candidate_outlet.id, product.id)
                raw_qty = post.get("qty_%s" % field_key)
                try:
                    qty = float(raw_qty or 0)
                except ValueError:
                    qty = 0
                if qty <= 0:
                    continue
                if not outlet:
                    outlet = candidate_outlet
                if candidate_outlet != outlet:
                    return self._render_error("Please order from one outlet at a time.")
                allergens = post.getlist("allergens_%s" % field_key) if hasattr(post, 'getlist') else []
                if not allergens and post.get("allergens_%s" % field_key):
                    allergens = [post.get("allergens_%s" % field_key)]
                selected_lines.append(
                    (
                        product,
                        qty,
                        candidate_outlet._get_pos_product_price(product, qty),
                        (post.get("note_%s" % field_key) or "").strip(),
                        ", ".join(allergens) if allergens else "",
                    )
                )

        if not selected_lines:
            return self._render_error("Please select at least one item before reviewing your order.")

        req_time = (post.get("requested_delivery_time") or post.get("delivery_time") or "ASAP").strip()
        order = request.env["hotel.room.service.order"].sudo().create(
            {
                "token_id": token_record.id,
                "reservation_id": reservation.id,
                "outlet_id": outlet.id,
                "payment_method": "bill_to_room",
                "guest_submitted": False,
                "requested_delivery_time": req_time,
                "guest_note": (post.get("guest_note") or "").strip(),
                "line_ids": [
                    (
                        0,
                        0,
                        {
                            "product_id": product.id,
                            "name": product.display_name,
                            "quantity": qty,
                            "price_unit": price,
                            "note": note,
                            "allergen_flags": allergen_flags,
                        },
                    )
                    for product, qty, price, note, allergen_flags in selected_lines
                ],
            }
        )
        return request.render("hotel_room_service_qr.room_service_review", {"order": order})

    @http.route("/room-service/order/<string:access_token>/confirm", type="http", auth="public", website=True, methods=["POST"], csrf=True)
    def room_service_confirm(self, access_token, **post):
        order = request.env["hotel.room.service.order"].sudo().search([("access_token", "=", access_token)], limit=1)
        if not order:
            return self._render_error("Order not found.", status=404)
        order.action_guest_submit()
        return request.redirect("/room-service/order/%s/status" % order.access_token)

    @http.route("/room-service/order/<string:access_token>/cancel", type="http", auth="public", website=True, methods=["POST"], csrf=True)
    def room_service_cancel(self, access_token, **post):
        order = request.env["hotel.room.service.order"].sudo().search([("access_token", "=", access_token)], limit=1)
        if not order:
            return self._render_error("Order not found.", status=404)
        order.action_guest_cancel()
        return request.render("hotel_room_service_qr.room_service_cancelled", {"order": order})

    @http.route("/room-service/order/<string:access_token>/status", type="http", auth="public", website=True)
    def room_service_status(self, access_token, **kw):
        order = request.env["hotel.room.service.order"].sudo().search([("access_token", "=", access_token)], limit=1)
        if not order:
            return self._render_error("Order not found.", status=404)
        return request.render("hotel_room_service_qr.room_service_status", {"order": order})

    @http.route("/room-service/order/<string:access_token>/status/json", type="jsonrpc", auth="public", website=True)
    def room_service_status_json(self, access_token, **kw):
        order = request.env["hotel.room.service.order"].sudo().search([("access_token", "=", access_token)], limit=1)
        if not order:
            return {"error": "Order not found"}
        return {
            "state": order.state,
            "state_label": dict(order._fields['state'].selection).get(order.state, order.state),
            "last_error": order.last_error or "",
            "updated_at": order.write_date.strftime("%Y-%m-%d %H:%M:%S") if order.write_date else "",
            "updated_at_display": order.write_date.strftime("%b %d, %I:%M %p") if order.write_date else "",
        }

    @http.route("/room-service/order/<string:access_token>/completed", type="http", auth="public", website=True, methods=["POST"], csrf=True)
    def room_service_completed(self, access_token, **post):
        order = request.env["hotel.room.service.order"].sudo().search([("access_token", "=", access_token)], limit=1)
        if not order:
            return self._render_error("Order not found.", status=404)
        return self._render_error(
            "Room-service staff completes and posts the order after delivery and receipt signature.",
            status=403,
        )
