def post_init_hook(env):
    env["res.company"].sudo().search([])._ensure_room_charge_accounting_setup()
    outlet_model = env["hotel.room.service.outlet"].sudo().with_context(
        room_service_installing=True,
        room_service_skip_session_open=True,
    )
    outlet = outlet_model._ensure_default_room_service_setup()
    outlet.sudo()._ensure_eh_kds_setup()
    try:
        Ticket = env['eh.kds.ticket'].sudo()
        RoomOrder = env['hotel.room.service.order'].sudo()

        room_orders = RoomOrder.search([])
        room_orders._compute_display_order_number()
        for order in room_orders:
            ref = order._eh_kds_ticket_ref()
            tickets = Ticket.search(['|', ('internal_note', '=', order._eh_kds_ticket_key()), ('pos_order_id', '=', order.pos_order_id.id if order.pos_order_id else 0)])
            if tickets:
                tickets.write({'ticket_ref': ref})
            if order.state in order._eh_kds_visible_states():
                order._sync_eh_kds_status_from_room_service()

        for ticket in Ticket.search([('pos_order_id', '!=', False)]):
            pos_ord = ticket.pos_order_id
            if pos_ord:
                ref = pos_ord._eh_kds_ref()
                if ticket.ticket_ref != ref:
                    ticket.write({'ticket_ref': ref})
    except Exception:
        pass


def uninstall_hook(env):
    """Hide module-provisioned POS configs when Room Service is removed."""
    outlet_model = env["hotel.room.service.outlet"].sudo()
    pos_config_model = env["pos.config"].sudo()

    outlets = outlet_model.search(["|", ("code", "=", "ROOM"), ("name", "=", "Room Service")])
    configs = outlets.mapped("pos_config_id")
    configs |= pos_config_model.search([
        ("name", "in", ["Room Service", "Room Service POS"]),
        ("self_ordering_mode", "in", ["mobile", "consultation"]),
    ])
    configs = configs.filtered(lambda config: config.exists())

    for config in configs:
        draft_orders = config.session_ids.order_ids.filtered(lambda order: order.state == "draft")
        if draft_orders:
            draft_orders.write({"state": "cancel"})

        open_sessions = config.session_ids.filtered(lambda session: session.state in ["opening_control", "opened"])
        empty_open_sessions = open_sessions.filtered(lambda session: not session.order_ids.filtered(lambda order: order.state not in ["draft", "cancel"]))
        if empty_open_sessions:
            empty_open_sessions.write({"state": "closed"})

        env.cr.execute(
            """
            UPDATE pos_config
               SET active = false,
                   self_ordering_mode = 'nothing',
                   self_ordering_service_mode = 'counter'
             WHERE id = %s
            """,
            [config.id],
        )
