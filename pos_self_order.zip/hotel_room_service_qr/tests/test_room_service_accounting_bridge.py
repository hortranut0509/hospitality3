from datetime import timedelta

from odoo import Command, fields
from odoo.exceptions import UserError
from odoo.tests import TransactionCase, tagged


@tagged("post_install", "-at_install", "room_service_kds")
class TestRoomServiceAccountingBridge(TransactionCase):
    @classmethod
    def setUpClass(cls):
        super().setUpClass()
        cls.company = cls.env.company
        cls.company._ensure_room_charge_accounting_setup()
        cls.partner = cls.env["res.partner"].create({"name": "Room Charge Accounting Guest"})
        cls.room_type = cls.env["hotel.room.type"].create({"name": "Accounting Test Room Type"})
        cls.zone = cls.env["hotel.zone"].create({"name": "Accounting Test Zone"})
        cls.floor = cls.env["hotel.floor"].create({"name": "A", "zone_id": cls.zone.id})
        cls.room = cls.env["hotel.room"].create({
            "name": "A101",
            "zone_id": cls.zone.id,
            "floor_id": cls.floor.id,
            "room_type_id": cls.room_type.id,
        })
        today = fields.Date.today()
        cls.reservation = cls.env["hotel.reservation"].sudo().with_context(
            hotel_reservation_security_bypass=True
        ).create({
            "partner_id": cls.partner.id,
            "room_type_id": cls.room_type.id,
            "room_id": cls.room.id,
            "checkin_date": today,
            "checkout_date": today + timedelta(days=1),
            "company_id": cls.company.id,
            "is_manual_rate": True,
            "manual_rate": 100.0,
        })
        cls.folio = cls.env["sale.order"].create({"partner_id": cls.partner.id})
        cls.reservation.sudo().write({"sale_order_id": cls.folio.id})
        cls.product = cls.env["product.product"].create({
            "name": "Accounting Test Meal",
            "sale_ok": True,
            "list_price": 12.0,
        })

        PaymentMethod = cls.env["pos.payment.method"].sudo().with_company(cls.company)
        payment_values = {
            "name": "Accounting Test Bill To Room",
            "is_room_charge": True,
            "receivable_account_id": cls.company.room_charge_pos_receivable_account_id.id,
        }
        if "company_id" in PaymentMethod._fields:
            payment_values["company_id"] = cls.company.id
        cls.payment_method = PaymentMethod.create(payment_values)
        cls.pos_config = cls.env["pos.config"].create({
            "name": "Room Charge Accounting Test POS",
            "payment_method_ids": [Command.link(cls.payment_method.id)],
        })
        cls.pos_session = cls.env["pos.session"].create({
            "config_id": cls.pos_config.id,
            "user_id": cls.env.uid,
        })

    def _pos_order_with_room_charge_payment(self, amount=12.0):
        order = self.env["pos.order"].sudo().create({
            "partner_id": self.partner.id,
            "amount_tax": 0.0,
            "amount_total": amount,
            "amount_paid": amount,
            "amount_return": 0.0,
            "session_id": self.pos_session.id,
            "hotel_reservation_id": self.reservation.id,
            "pos_reference": "ACCOUNTING-TEST-%s" % fields.Datetime.now(),
        })
        self.env["pos.payment"].sudo().create({
            "pos_order_id": order.id,
            "payment_method_id": self.payment_method.id,
            "amount": amount,
            "payment_date": fields.Datetime.now(),
        })
        return order

    def test_accounting_setup_uses_standard_account_types(self):
        self.company._validate_room_charge_accounting_setup()
        self.assertEqual(self.company.room_charge_pos_receivable_account_id.account_type, "asset_receivable")
        self.assertTrue(self.company.room_charge_pos_receivable_account_id.reconcile)
        self.assertEqual(self.company.room_charge_folio_clearing_account_id.account_type, "asset_current")
        self.assertTrue(self.company.room_charge_folio_clearing_account_id.reconcile)
        self.assertEqual(self.company.room_charge_transfer_journal_id.type, "general")
        self.assertFalse(self.company.room_charge_transfer_product_id.taxes_id)
        self.assertEqual(
            self.company.room_charge_transfer_product_id._get_product_accounts()["income"],
            self.company.room_charge_folio_clearing_account_id,
        )

    def test_bridge_is_idempotent_and_contains_no_revenue_or_vat(self):
        pos_order = self._pos_order_with_room_charge_payment()
        first_line = pos_order._post_room_charge_to_folio_accounting_bridge(
            self.reservation,
            12.0,
            pos_order.pos_reference,
        )
        first_move = pos_order.room_charge_bridge_move_id
        second_line = pos_order._post_room_charge_to_folio_accounting_bridge(
            self.reservation,
            12.0,
            pos_order.pos_reference,
        )

        self.assertEqual(first_line, second_line)
        self.assertEqual(first_move, pos_order.room_charge_bridge_move_id)
        self.assertEqual(first_move.state, "posted")
        self.assertEqual(
            self.env["account.move"].search_count([("room_charge_pos_order_id", "=", pos_order.id)]),
            1,
        )
        self.assertEqual(
            self.env["sale.order.line"].search_count([("room_charge_pos_order_id", "=", pos_order.id)]),
            1,
        )
        self.assertFalse(first_line.tax_ids)
        self.assertEqual(first_line.product_id, self.company.room_charge_transfer_product_id)
        self.assertFalse(first_move.line_ids.filtered(
            lambda line: line.account_id.account_type in ("income", "income_other")
        ))
        self.assertFalse(first_move.line_ids.filtered("tax_line_id"))
        self.assertEqual(
            sum(first_move.line_ids.filtered(
                lambda line: line.account_id == self.company.room_charge_folio_clearing_account_id
            ).mapped("balance")),
            12.0,
        )
        self.assertEqual(
            sum(first_move.line_ids.filtered(
                lambda line: line.account_id == self.company.room_charge_pos_receivable_account_id
            ).mapped("balance")),
            -12.0,
        )

    def test_folio_invoice_credits_clearing_not_revenue(self):
        pos_order = self._pos_order_with_room_charge_payment()
        pos_order._post_room_charge_to_folio_accounting_bridge(
            self.reservation,
            12.0,
            pos_order.pos_reference,
        )
        self.folio.action_confirm()
        invoice = self.folio._create_invoices()
        self.assertEqual(len(invoice), 1)
        self.assertEqual(invoice.amount_total, 12.0)
        self.assertEqual(invoice.amount_tax, 0.0)
        invoice.action_post()
        clearing_lines = invoice.line_ids.filtered(
            lambda line: line.account_id == self.company.room_charge_folio_clearing_account_id
        )
        revenue_lines = invoice.line_ids.filtered(
            lambda line: line.account_id.account_type in ("income", "income_other")
        )
        self.assertEqual(sum(clearing_lines.mapped("balance")), -12.0)
        self.assertFalse(revenue_lines)
        self.assertFalse(invoice.line_ids.filtered("tax_line_id"))

    def test_wrong_payment_account_fails_before_business_posting(self):
        pos_order = self._pos_order_with_room_charge_payment()
        wrong_receivable = self.env["account.account"].sudo().with_company(self.company).search([
            ("account_type", "=", "asset_receivable"),
            ("id", "!=", self.company.room_charge_pos_receivable_account_id.id),
        ], limit=1)
        self.assertTrue(wrong_receivable)
        self.company.room_charge_pos_receivable_account_id = wrong_receivable
        with self.assertRaises(UserError):
            pos_order._post_room_charge_to_folio_accounting_bridge(
                self.reservation,
                12.0,
                pos_order.pos_reference,
            )
        self.assertFalse(pos_order.room_charge_bridge_move_id)
        self.assertFalse(pos_order.room_charge_folio_line_id)
