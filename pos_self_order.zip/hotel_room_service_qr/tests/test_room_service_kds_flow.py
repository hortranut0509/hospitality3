from datetime import timedelta

from psycopg2 import IntegrityError

from odoo import fields
from odoo.exceptions import UserError
from odoo.tests import TransactionCase, tagged

from odoo.addons.hotel_room_service_qr.controllers.room_service import HotelRoomServiceQrController


@tagged("post_install", "-at_install", "room_service_kds")
class TestRoomServiceKdsFlow(TransactionCase):
    @classmethod
    def setUpClass(cls):
        super().setUpClass()
        cls.env["eh.kds.board"].search([]).write({"active": False})
        cls.board = cls.env["eh.kds.board"].create({"name": "Room Service Kitchen"})
        cls.product_a = cls.env["product.product"].create({"name": "Club Sandwich", "sale_ok": True})
        cls.product_b = cls.env["product.product"].create({"name": "Fresh Juice", "sale_ok": True})
        cls.partner = cls.env["res.partner"].create({"name": "Room Service Guest"})
        cls.room_type = cls.env["hotel.room.type"].create({"name": "Deluxe"})
        cls.zone = cls.env["hotel.zone"].create({"name": "Tower A"})
        cls.floor = cls.env["hotel.floor"].create({"name": "1", "zone_id": cls.zone.id})
        cls.room = cls.env["hotel.room"].create({
            "name": "101",
            "zone_id": cls.zone.id,
            "floor_id": cls.floor.id,
            "room_type_id": cls.room_type.id,
        })
        today = fields.Date.today()
        cls.reservation = cls.env["hotel.reservation"].sudo().with_context(
            hotel_reservation_security_bypass=True
        ).create({
            "partner_id": cls.partner.id,
            "room_type_id": cls.room_type.id,
            "room_id": cls.room.id,
            "checkin_date": today,
            "checkout_date": today + timedelta(days=1),
            "company_id": cls.env.company.id,
            "is_manual_rate": True,
            "manual_rate": 100.0,
        })
        cls.folio = cls.env["sale.order"].create({"partner_id": cls.partner.id})
        cls.reservation.sudo().write({"sale_order_id": cls.folio.id})
        cls.outlet = cls.env["hotel.room.service.outlet"].with_context(
            room_service_installing=True,
            room_service_skip_session_open=True,
        ).create({"name": "Room Service", "code": "ROOM", "auto_create_pos_order": False})
        cls.pos_config = cls.env["pos.config"].search([], limit=1)
        if not cls.pos_config:
            cls.pos_config = cls.env["pos.config"].create({"name": "Room Service POS"})
        cls.pos_session = cls.env["pos.session"].search([
            ("config_id", "=", cls.pos_config.id),
            ("state", "=", "opened"),
        ], limit=1)
        if not cls.pos_session:
            cls.pos_session = cls.env["pos.session"].create({
                "config_id": cls.pos_config.id,
                "user_id": cls.env.uid,
            })

    def _room_service_order(self, outlet=None):
        outlet = outlet or self.outlet
        return self.env["hotel.room.service.order"].sudo().create({
            "reservation_id": self.reservation.id,
            "outlet_id": outlet.id,
            "payment_method": "bill_to_room",
            "line_ids": [
                (0, 0, {
                    "product_id": self.product_a.id,
                    "name": "Club Sandwich",
                    "quantity": 1.0,
                    "price_unit": 12.0,
                }),
            ],
        })

    def _ticket_with_cards(self, order, products=None):
        products = products or [self.product_a]
        ticket = self.env["eh.kds.ticket"].create({
            "ticket_ref": order._eh_kds_ticket_ref(),
            "internal_note": order._eh_kds_ticket_key(),
        })
        cards = self.env["eh.kds.card"]
        for index, product in enumerate(products, start=1):
            item = self.env["eh.kds.ticket.item"].create({
                "ticket_id": ticket.id,
                "product_id": product.id,
                "quantity": 1.0,
                "pos_order_line_uuid": "%s:%s" % (order._eh_kds_ticket_key(), index),
            })
            card = self.env["eh.kds.card"].create({
                "item_id": item.id,
                "lane_id": self.board.lane_ids[0].id,
            })
            card._log("placed", to_lane=self.board.lane_ids[0], push=False)
            cards |= card
        return ticket, cards

    def test_kds_move_syncs_room_service_status(self):
        order = self._room_service_order()
        _ticket, cards = self._ticket_with_cards(order)
        cards.move_to(1)
        self.assertEqual(order.state, "kitchen_preparing")
        cards.move_to(2)
        self.assertEqual(order.state, "kitchen_ready")
        cards.move_to(3)
        self.assertEqual(order.state, "kitchen_ready")
        logs = self.env["hotel.room.service.integration.log"].search([
            ("order_id", "=", order.id),
            ("adapter", "=", "kds"),
            ("status", "=", "success"),
        ])
        self.assertEqual(len(logs), 2)
        self.assertIn("Kitchen Display updated Room Service status", logs[0].message)

    def test_partial_kds_void_does_not_cancel_room_service(self):
        order = self._room_service_order()
        _ticket, cards = self._ticket_with_cards(order, [self.product_a, self.product_b])
        cards[0].void(reason="item unavailable")
        self.assertNotEqual(order.state, "cancelled")
        cards[1].void(reason="all items unavailable")
        self.assertEqual(order.state, "cancelled")

    def test_room_service_cancel_voids_existing_kds_ticket(self):
        order = self._room_service_order()
        _ticket, cards = self._ticket_with_cards(order)
        order.write({"state": "sent_pos"})
        order.action_cancel_before_pos()
        self.assertEqual(order.state, "cancelled")
        self.assertTrue(all(card.status == "voided" for card in cards))

    def test_folio_posting_is_idempotent(self):
        order = self._room_service_order()
        order.write({"state": "delivered"})
        order._post_to_pms_folio()
        lines = order._find_existing_pms_folio_lines(self.folio)
        self.assertEqual(len(lines), 1)
        order.write({
            "pms_sync_state": "failed",
            "state": "guest_confirmed",
            "folio_posted_at": False,
            "last_error": "simulated retry after partial posting",
        })
        order._post_to_pms_folio()
        self.assertEqual(len(order._find_existing_pms_folio_lines(self.folio)), 1)
        self.assertEqual(order.pms_sync_state, "posted")

    def test_bill_to_room_is_blocked_for_checked_out_reservation(self):
        self.reservation.sudo().with_context(hotel_allow_checkout_state_write=True).write({"state": "checkout"})
        with self.assertRaises(UserError):
            self._room_service_order()

        order = self.env["hotel.room.service.order"].sudo().create({
            "reservation_id": self.reservation.id,
            "outlet_id": self.outlet.id,
            "payment_method": "pay_at_pos",
            "line_ids": [
                (0, 0, {
                    "product_id": self.product_a.id,
                    "name": "Club Sandwich",
                    "quantity": 1.0,
                    "price_unit": 12.0,
                }),
            ],
        })
        self.assertEqual(order.payment_method, "pay_at_pos")

    def test_bill_to_room_rechecks_reservation_before_confirm(self):
        order = self._room_service_order()
        self.reservation.sudo().with_context(hotel_allow_checkout_state_write=True).write({"state": "checkout"})
        with self.assertRaises(UserError):
            order.action_confirm_and_send()
        self.assertEqual(order.state, "draft")

    def test_auto_create_pos_order_opens_room_service_pos_session(self):
        pos_config = self.env["pos.config"].create({"name": "Room Service Auto Session"})
        outlet = self.env["hotel.room.service.outlet"].with_context(
            room_service_installing=True,
            room_service_skip_session_open=True,
        ).create({
            "name": "Room Service Auto Session",
            "code": "AUTO",
            "pos_config_id": pos_config.id,
            "auto_create_pos_order": True,
        })
        self.assertFalse(self.env["pos.session"].search([
            ("config_id", "=", pos_config.id),
            ("state", "=", "opened"),
        ]))

        order = self._room_service_order(outlet=outlet)
        order.action_confirm_and_send()

        self.assertEqual(order.state, "draft")
        self.assertFalse(order.pos_order_id)
        self.assertTrue(order.guest_submitted)

        order.action_confirm_to_pos()

        self.assertEqual(order.state, "sent_pos")
        self.assertTrue(order.pos_order_id)
        self.assertEqual(order.pos_order_id.state, "draft")
        self.assertEqual(order.pos_order_id.session_id.state, "opened")

    def test_guest_submission_waits_for_staff_review(self):
        order = self._room_service_order()
        order.write({"guest_submitted": False, "guest_submitted_at": False})

        order.action_guest_submit()

        self.assertEqual(order.state, "draft")
        self.assertTrue(order.guest_submitted)
        self.assertTrue(order.guest_submitted_at)
        self.assertFalse(order.pos_order_id)

    def test_guest_progress_mapping_matches_room_service_workflow(self):
        expected_steps = {
            "draft": 0,
            "confirmed": 1,
            "sent_pos": 1,
            "pos_failed": 1,
            "kitchen_preparing": 2,
            "kitchen_ready": 3,
            "delivered": 4,
            "guest_confirmed": 4,
            "folio_posted": 4,
            "paid_pos": 4,
            "closed": 4,
            "cancelled": 0,
        }
        self.assertEqual(
            HotelRoomServiceQrController.GUEST_PROGRESS_STEP_BY_STATE,
            expected_steps,
        )

    def test_guest_progress_template_applies_dom_classes_after_render(self):
        view = self.env.ref("hotel_room_service_qr.room_service_menu")
        arch = view.arch_db

        self.assertIn("function applyOrderProgressState", arch)
        self.assertIn("data-progress-index=\"1\"", arch)
        self.assertIn("node.classList.toggle('completed', isCompleted)", arch)
        self.assertIn("node.classList.toggle('current', isCurrent)", arch)
        self.assertIn("applyOrderProgressState(container, orders)", arch)
        self.assertNotIn("class=\"step-node ' +", arch)

    def test_guest_timezone_uses_hotel_company_timezone(self):
        self.env.company.partner_id.tz = "Asia/Phnom_Penh"
        order = self._room_service_order()

        display_timezone = HotelRoomServiceQrController()._get_guest_display_timezone(order)

        self.assertEqual(display_timezone, "Asia/Phnom_Penh")

    def test_guest_request_key_prevents_duplicate_order(self):
        request_key = "room-101-browser-request-1"
        order = self._room_service_order()
        order.write({"guest_request_key": request_key})

        with self.assertRaises(IntegrityError):
            with self.env.cr.savepoint():
                self.env["hotel.room.service.order"].sudo().create({
                    "reservation_id": self.reservation.id,
                    "outlet_id": self.outlet.id,
                    "payment_method": "bill_to_room",
                    "guest_request_key": request_key,
                    "line_ids": [
                        (0, 0, {
                            "product_id": self.product_a.id,
                            "name": "Club Sandwich",
                            "quantity": 1.0,
                            "price_unit": 12.0,
                        }),
                    ],
                })

    def test_guest_cannot_complete_or_cancel_after_staff_acceptance(self):
        order = self._room_service_order()
        order.action_guest_submit()
        order.action_confirm_to_pos()

        with self.assertRaises(UserError):
            order.action_guest_confirm_completed()
        with self.assertRaises(UserError):
            order.action_guest_cancel()

    def test_staff_completion_requires_delivery_and_posts_once(self):
        order = self._room_service_order()
        with self.assertRaises(UserError):
            order.action_complete_and_post()

        order.write({"state": "kitchen_ready"})
        order.action_delivered()
        self.assertEqual(order.delivered_by_id, self.env.user)
        self.assertTrue(order.delivered_at)
        order.action_complete_and_post()

        self.assertEqual(order.state, "folio_posted")
        self.assertEqual(order.pms_sync_state, "posted")
        self.assertTrue(order.completed_at)
        self.assertEqual(order.completed_by_id, self.env.user)
        self.assertEqual(len(order._find_existing_pms_folio_lines(self.folio)), 1)

        order.action_complete_and_post()
        self.assertEqual(len(order._find_existing_pms_folio_lines(self.folio)), 1)

    def test_completion_recovers_existing_folio_line(self):
        order = self._room_service_order()
        order.write({"state": "kitchen_ready"})
        order.action_delivered()
        self.env["sale.order.line"].sudo().create({
            "order_id": self.folio.id,
            "product_id": self.product_a.id,
            "name": "%s / Room Service: Club Sandwich" % order.name,
            "product_uom_qty": 1.0,
            "price_unit": 12.0,
            "hotel_reservation_id": self.reservation.id,
        })

        order.action_complete_and_post()

        self.assertEqual(order.state, "folio_posted")
        self.assertEqual(order.pms_sync_state, "posted")
        self.assertEqual(len(order._find_existing_pms_folio_lines(self.folio)), 1)

    def test_room_service_self_order_is_hidden_from_visible_pos_domain(self):
        PosOrder = self.env["pos.order"].sudo()
        hidden = PosOrder.create({
            "partner_id": self.partner.id,
            "amount_tax": 0.0,
            "amount_total": 12.0,
            "amount_paid": 0.0,
            "amount_return": 0.0,
            "session_id": self.pos_session.id,
            "is_room_service_pending": True,
            "floating_order_name": "Room Service / Room 101",
        })
        visible = PosOrder.create({
            "partner_id": self.partner.id,
            "amount_tax": 0.0,
            "amount_total": 8.0,
            "amount_paid": 0.0,
            "amount_return": 0.0,
            "session_id": self.pos_session.id,
            "is_room_service_pending": False,
            "floating_order_name": "Normal POS Order",
        })

        visible_orders = PosOrder.search([
            ("id", "in", [hidden.id, visible.id]),
            ("is_room_service_pending", "=", False),
        ])
        self.assertNotIn(hidden, visible_orders)
        self.assertIn(visible, visible_orders)
        self.assertIsNone(hidden._send_notification(hidden))

    def test_guest_and_monitor_catalogs_match_room_service_products(self):
        allowed_category = self.env["pos.category"].create({"name": "Room Service Allowed"})
        blocked_category = self.env["pos.category"].create({"name": "Room Service Blocked"})
        allowed_product = self.env["product.product"].create({"name": "POS Visible Soup", "sale_ok": True})
        allowed_product.product_tmpl_id.write({
            "available_in_pos": True,
            "available_in_room_service": True,
            "pos_categ_ids": [(6, 0, allowed_category.ids)],
            "room_service_description": "Prepared from the Product setup.",
            "room_service_sequence": 2,
        })
        blocked_product = self.env["product.product"].create({"name": "POS Hidden Steak", "sale_ok": True})
        blocked_product.product_tmpl_id.write({
            "available_in_pos": True,
            "available_in_room_service": True,
            "pos_categ_ids": [(6, 0, blocked_category.ids)],
        })
        unchecked_product = self.env["product.product"].create({"name": "Not Room Service", "sale_ok": True})
        unchecked_product.product_tmpl_id.write({
            "available_in_pos": True,
            "available_in_room_service": False,
            "pos_categ_ids": [(6, 0, allowed_category.ids)],
        })
        self.pos_config.write({
            "limit_categories": True,
            "iface_available_categ_ids": [(6, 0, allowed_category.ids)],
        })
        self.outlet.write({"pos_config_id": self.pos_config.id})

        products = self.outlet._get_available_pos_products()
        self.assertIn(allowed_product, products)
        self.assertNotIn(blocked_product, products)
        self.assertNotIn(unchecked_product, products)

        guest_payload = self.outlet.get_pos_menu_payload()
        guest_product_ids = {item["product_id"] for item in guest_payload["items"]}

        items, _categories = HotelRoomServiceQrController()._get_monitor_change_payload(self.outlet)
        monitor_product_ids = {item["product_id"] for item in items}
        self.assertEqual(monitor_product_ids, guest_product_ids)
        self.assertIn(allowed_product.id, monitor_product_ids)
        self.assertNotIn(blocked_product.id, monitor_product_ids)
        self.assertNotIn(unchecked_product.id, monitor_product_ids)

        guest_item = next(
            item for item in guest_payload["items"] if item["product_id"] == allowed_product.id
        )
        monitor_item = next(item for item in items if item["product_id"] == allowed_product.id)
        self.assertEqual(guest_item["name"], allowed_product.display_name)
        self.assertEqual(guest_item["description"], "Prepared from the Product setup.")
        self.assertEqual(monitor_item["name"], guest_item["name"])
        self.assertEqual(monitor_item["price"], guest_item["price"])
        self.assertEqual(monitor_item["description"], guest_item["description"])
