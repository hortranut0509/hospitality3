"""Preserve visibility of orders created before guest submission tracking."""


def migrate(cr, version):
    cr.execute(
        """
        UPDATE hotel_room_service_order
           SET guest_submitted = TRUE,
               guest_submitted_at = COALESCE(guest_submitted_at, create_date)
         WHERE guest_submitted IS DISTINCT FROM TRUE
            OR guest_submitted_at IS NULL
        """
    )
