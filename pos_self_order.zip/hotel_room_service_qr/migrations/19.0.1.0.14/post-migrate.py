"""Provision the 0.14 clearing records without changing active POS payment methods."""

from odoo import SUPERUSER_ID, api


def migrate(cr, version):
    env = api.Environment(cr, SUPERUSER_ID, {})
    env["res.company"].sudo().search([])._ensure_room_charge_accounting_setup()
