"""Move the legacy Room Service menu selection onto Product setup."""


def migrate(cr, version):
    cr.execute(
        """
        WITH ranked_legacy_items AS (
            SELECT pp.product_tmpl_id,
                   menu.category_id,
                   menu.sequence,
                   menu.description,
                   ROW_NUMBER() OVER (
                       PARTITION BY pp.product_tmpl_id
                       ORDER BY menu.sequence, menu.id
                   ) AS item_rank
              FROM hotel_room_service_menu_item AS menu
              JOIN product_product AS pp
                ON pp.id = menu.product_id
             WHERE menu.active IS TRUE
        )
        UPDATE product_template AS template
           SET available_in_room_service = TRUE,
               available_in_pos = TRUE,
               room_service_category_id = COALESCE(
                   template.room_service_category_id,
                   legacy.category_id
               ),
               room_service_sequence = legacy.sequence,
               room_service_description = COALESCE(
                   NULLIF(template.room_service_description, ''),
                   legacy.description
               )
          FROM ranked_legacy_items AS legacy
         WHERE legacy.item_rank = 1
           AND legacy.product_tmpl_id = template.id
        """
    )
