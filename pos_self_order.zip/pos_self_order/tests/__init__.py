# Part of Odoo. See LICENSE file for full copyright and licensing details.

from . import test_frontend
from . import self_order_common_test
from . import test_res_config_settings
from . import test_self_order_mobile
from . import test_self_order_kiosk
from . import test_self_order_attribute
from . import test_self_order_combo
from . import test_self_order_common
from . import test_webmanifest
from . import test_self_order_sequence
from . import test_self_order_preset
from . import test_self_order_controller
from . import test_takeaway_preset_mail
from . import test_self_order_prices
