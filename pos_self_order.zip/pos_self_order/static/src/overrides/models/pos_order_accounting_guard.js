import { PosOrderAccounting } from "@point_of_sale/app/models/accounting/pos_order_accounting";
import { patch } from "@web/core/utils/patch";

patch(PosOrderAccounting.prototype, {
    _computeAllPrices(opts = {}) {
        return super._computeAllPrices({
            ...opts,
            lines: opts.lines || this.lines || [],
        });
    },
});
